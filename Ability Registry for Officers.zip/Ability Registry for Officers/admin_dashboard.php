<?php
session_start();
require_once 'connection.php';

// Debug session data
error_log("Session data: " . print_r($_SESSION, true));

// Check if user is logged in and is admin (case-insensitive check)
if (!isset($_SESSION['logged_in']) || $_SESSION['logged_in'] !== true) {
    error_log("User not logged in, redirecting to login");
    header('Location: login.html');
    exit;
}

// Case-insensitive role check
$userRole = isset($_SESSION['role']) ? strtolower(trim($_SESSION['role'])) : '';
if ($userRole !== 'admin') {
    error_log("User role is not admin. Role: " . $_SESSION['role'] . ", Redirecting to officer dashboard");
    header('Location: officer_dashboard.php');
    exit;
}

// Get admin's location information from session or database
$admin_id = $_SESSION['user_id'];
$admin_dsid = $_SESSION['dsid'] ?? null;
$admin_district_id = $_SESSION['district_id'] ?? null;
$admin_province_id = $_SESSION['Province_id'] ?? null;

// Get division name for display
$admin_division_name = "Unknown Division";
if ($admin_dsid) {
    $division_query = "SELECT dsname FROM dsdivision WHERE dsid = ?";
    $stmt = $pdo->prepare($division_query);
    $stmt->execute([$admin_dsid]);
    $division_result = $stmt->fetch(PDO::FETCH_ASSOC);
    $admin_division_name = $division_result['dsname'] ?? "Unknown Division";
}

error_log("Admin location - DSID: $admin_dsid, District: $admin_district_id, Province: $admin_province_id");

// Get statistics for admin dashboard - filtered by admin's access level
$stats_query = "SELECT COUNT(*) FROM user WHERE 1=1";
$stats_params = [];

if ($admin_dsid) {
    $stats_query .= " AND dsid = ?";
    $stats_params[] = $admin_dsid;
} elseif ($admin_district_id) {
    $stats_query .= " AND district_id = ?";
    $stats_params[] = $admin_district_id;
}

$total_officers = $pdo->prepare($stats_query);
$total_officers->execute($stats_params);
$total_officers = $total_officers->fetchColumn();

// Get abilities count based on admin's access level
$abilities_query = "
    SELECT COUNT(*) 
    FROM ability a 
    JOIN user u ON a.user_id = u.ID 
    WHERE 1=1
";
$abilities_params = [];

if ($admin_dsid) {
    $abilities_query .= " AND u.dsid = ?";
    $abilities_params[] = $admin_dsid;
} elseif ($admin_district_id) {
    $abilities_query .= " AND u.district_id = ?";
    $abilities_params[] = $admin_district_id;
}

$total_abilities = $pdo->prepare($abilities_query);
$total_abilities->execute($abilities_params);
$total_abilities = $total_abilities->fetchColumn();

// Handle search
$search_term = '';
$abilities = [];
$show_search_results = false;

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['search'])) {
    $search_term = trim($_GET['search']);
    $show_search_results = true;
    
    // Base query with access control
    $query = "
        SELECT 
            a.ability_id,
            a.ability_name,
            a.where_used,
            a.created_at,
            a.updated_at,
            u.Name as officer_name,
            u.Position,
            u.Contact,
            u.email,
            d.dsname as division,
            dist.district_name as district,
            p.province_name as province
        FROM ability a
        JOIN user u ON a.user_id = u.ID
        LEFT JOIN dsdivision d ON u.dsid = d.dsid
        LEFT JOIN district dist ON u.district_id = dist.district_id
        LEFT JOIN provinces p ON u.Province_id = p.province_id
        WHERE 1=1
    ";
    
    $params = [];
    
    // Add access control filters
    if ($admin_dsid) {
        $query .= " AND u.dsid = ?";
        $params[] = $admin_dsid;
    } elseif ($admin_district_id) {
        $query .= " AND u.district_id = ?";
        $params[] = $admin_district_id;
    }
    
    // Add search filters if search term exists
    if (!empty($search_term)) {
        $query .= " AND (a.ability_name LIKE ? OR u.Name LIKE ? OR u.Position LIKE ?)";
        $search_pattern = "%$search_term%";
        $params[] = $search_pattern;
        $params[] = $search_pattern;
        $params[] = $search_pattern;
    }
    
    $query .= " ORDER BY a.created_at DESC";
    
    $stmt = $pdo->prepare($query);
    $stmt->execute($params);
    $abilities = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    error_log("Search executed with " . count($abilities) . " results. Query: " . $query);
    error_log("Search parameters: " . print_r($params, true));
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Divisional Office</title>
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
        }

        :root {
            --primary: #2563eb;
            --primary-dark: #1d4ed8;
            --secondary: #64748b;
            --success: #10b981;
            --warning: #f59e0b;
            --danger: #ef4444;
            --light: #f8fafc;
            --dark: #1e293b;
            --border: #e2e8f0;
            --shadow: 0 1px 3px 0 rgba(0, 0, 0, 0.1), 0 1px 2px 0 rgba(0, 0, 0, 0.06);
            --shadow-lg: 0 10px 15px -3px rgba(0, 0, 0, 0.1), 0 4px 6px -2px rgba(0, 0, 0, 0.05);
        }

        body {
            background: linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%);
            min-height: 100vh;
            color: var(--dark);
            line-height: 1.6;
        }

        .header {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 1.5rem 0;
            box-shadow: var(--shadow-lg);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 2rem;
        }

        .welcome h1 {
            font-size: 1.75rem;
            font-weight: 700;
            margin-bottom: 0.25rem;
        }

        .welcome p {
            opacity: 0.9;
            font-size: 0.95rem;
            font-weight: 500;
        }

        .admin-access {
            background: rgba(255, 255, 255, 0.2);
            padding: 0.5rem 1rem;
            border-radius: 0.5rem;
            font-size: 0.85rem;
            margin-top: 0.5rem;
            border: 1px solid rgba(255, 255, 255, 0.3);
        }

        .logout-btn {
            background: rgba(255, 255, 255, 0.15);
            color: white;
            border: 1px solid rgba(255, 255, 255, 0.3);
            padding: 0.75rem 1.5rem;
            border-radius: 0.75rem;
            cursor: pointer;
            text-decoration: none;
            transition: all 0.3s ease;
            font-weight: 600;
            backdrop-filter: blur(12px);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .logout-btn:hover {
            background: rgba(255, 255, 255, 0.25);
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(255, 255, 255, 0.15);
        }

        .dashboard-container {
            max-width: 1400px;
            margin: 2.5rem auto;
            padding: 0 2rem;
        }

        /* Updated stats grid - 2 columns instead of 4 */
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 1.5rem;
            margin-bottom: 3rem;
        }

        .stat-card {
            background: white;
            padding: 2rem 1.5rem;
            border-radius: 1rem;
            box-shadow: var(--shadow);
            border-left: 4px solid;
            transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
            position: relative;
            overflow: hidden;
        }

        .stat-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 3px;
            background: linear-gradient(90deg, transparent, rgba(255, 255, 255, 0.8), transparent);
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: var(--shadow-lg);
        }

        .stat-card:nth-child(1) { border-left-color: var(--primary); }
        .stat-card:nth-child(2) { border-left-color: var(--success); }

        .stat-icon {
            width: 3rem;
            height: 3rem;
            border-radius: 0.75rem;
            display: flex;
            align-items: center;
            justify-content: center;
            margin-bottom: 1rem;
            font-size: 1.25rem;
        }

        .stat-card:nth-child(1) .stat-icon { background: rgba(37, 99, 235, 0.1); color: var(--primary); }
        .stat-card:nth-child(2) .stat-icon { background: rgba(16, 185, 129, 0.1); color: var(--success); }

        .stat-number {
            font-size: 2.25rem;
            font-weight: 800;
            margin-bottom: 0.5rem;
            background: linear-gradient(135deg, var(--primary), var(--primary-dark));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
        }

        .stat-label {
            color: var(--secondary);
            font-size: 0.9rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .search-section {
            background: white;
            border-radius: 1rem;
            padding: 2.5rem;
            box-shadow: var(--shadow);
            margin-bottom: 2.5rem;
            border: 1px solid var(--border);
        }

        .search-section h3 {
            color: var(--dark);
            font-size: 1.5rem;
            font-weight: 700;
            margin-bottom: 1.5rem;
            display: flex;
            align-items: center;
            gap: 0.75rem;
        }

        .search-section h3 i {
            color: var(--primary);
        }

        .search-form {
            display: flex;
            gap: 1rem;
            margin-bottom: 1.5rem;
            align-items: center;
        }

        .search-input {
            flex: 1;
            padding: 1rem 1.5rem;
            border: 2px solid var(--border);
            border-radius: 0.75rem;
            font-size: 1rem;
            transition: all 0.3s ease;
            background: var(--light);
        }

        .search-input:focus {
            outline: none;
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
            background: white;
        }

        .search-btn {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 0.75rem;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .search-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(37, 99, 235, 0.3);
        }

        .print-btn {
            background: linear-gradient(135deg, var(--success) 0%, #059669 100%);
            color: white;
            border: none;
            padding: 1rem 2rem;
            border-radius: 0.75rem;
            font-size: 1rem;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            gap: 0.5rem;
            text-decoration: none;
        }

        .print-btn:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 25px rgba(16, 185, 129, 0.3);
        }

        .stats-info {
            display: flex;
            gap: 1rem;
            flex-wrap: wrap;
        }

        .stat-badge {
            background: var(--light);
            padding: 0.75rem 1.25rem;
            border-radius: 0.5rem;
            font-size: 0.875rem;
            font-weight: 600;
            color: var(--secondary);
            border: 1px solid var(--border);
        }

        .access-badge {
            background: linear-gradient(135deg, var(--primary) 0%, var(--primary-dark) 100%);
            color: white;
            padding: 0.75rem 1.25rem;
            border-radius: 0.5rem;
            font-size: 0.875rem;
            font-weight: 600;
            border: 1px solid var(--border);
        }

        .table-container {
            background: white;
            border-radius: 1rem;
            box-shadow: var(--shadow);
            overflow: hidden;
            border: 1px solid var(--border);
        }

        .abilities-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.9rem;
        }

        .abilities-table th {
            background: var(--light);
            padding: 1rem 0.75rem;
            text-align: left;
            font-weight: 700;
            color: var(--dark);
            border-bottom: 2px solid var(--border);
            font-size: 0.85rem;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .abilities-table td {
            padding: 1rem 0.75rem;
            border-bottom: 1px solid var(--border);
            vertical-align: top;
        }

        .abilities-table tr:last-child td {
            border-bottom: none;
        }

        .abilities-table tr:hover {
            background: #f8fafc;
        }

        .ability-name {
            font-weight: 600;
            color: var(--primary);
            font-size: 0.95rem;
            margin-bottom: 0.5rem;
        }

        .where-used {
            font-size: 0.85rem;
            line-height: 1.4;
            color: var(--secondary);
        }

        .officer-info {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        .officer-name {
            font-weight: 600;
            color: var(--dark);
            font-size: 0.9rem;
        }

        .contact-info {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        .contact-item {
            font-size: 0.8rem;
            color: var(--secondary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .location-info {
            display: flex;
            flex-direction: column;
            gap: 0.25rem;
        }

        .location-item {
            font-size: 0.8rem;
            color: var(--secondary);
            display: flex;
            align-items: center;
            gap: 0.5rem;
        }

        .no-results, .no-search {
            text-align: center;
            padding: 4rem 2rem;
            color: var(--secondary);
            background: white;
            border-radius: 1rem;
            box-shadow: var(--shadow);
        }

        .no-results h3, .no-search h3 {
            font-size: 1.375rem;
            margin-bottom: 1rem;
            color: var(--dark);
            font-weight: 600;
        }

        .no-results p, .no-search p {
            font-size: 1rem;
            max-width: 500px;
            margin: 0 auto;
        }

        .empty-icon {
            font-size: 3rem;
            color: var(--border);
            margin-bottom: 1.5rem;
        }

        @media print {
            body * {
                visibility: hidden;
            }
            .abilities-section, .abilities-section * {
                visibility: visible;
            }
            .abilities-section {
                position: absolute;
                left: 0;
                top: 0;
                width: 100%;
                box-shadow: none;
                border: none;
            }
            .print-btn, .search-section, .stats-grid, .header {
                display: none;
            }
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                text-align: center;
                gap: 1rem;
                padding: 0 1rem;
            }

            .dashboard-container {
                padding: 0 1rem;
                margin: 1.5rem auto;
            }

            .search-section, .abilities-section {
                padding: 1.5rem;
            }

            .search-form {
                flex-direction: column;
            }

            .stats-grid {
                grid-template-columns: 1fr;
                gap: 1rem;
            }

            .table-container {
                overflow-x: auto;
            }

            .abilities-table {
                min-width: 700px;
            }
        }

        @media (max-width: 480px) {
            .stat-card {
                padding: 1.5rem 1rem;
            }

            .stat-number {
                font-size: 1.875rem;
            }

            .search-section h3, .section-header h3 {
                font-size: 1.25rem;
            }
        }
    </style>
</head>
<body>
    <div class="header">
        <div class="header-content">
            <div class="welcome">
                <h1>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></h1>
                <p>Administrator Dashboard - Ability Registry for Officers System</p>
                <div class="admin-access">
                    <i class="fas fa-shield-alt"></i>
                    Access Level: 
                    <?php 
                    if ($admin_dsid) {
                        echo "Division Level (" . htmlspecialchars($admin_division_name) . ")";
                    } elseif ($admin_district_id) {
                        echo "District Level (District ID: $admin_district_id)";
                    } else {
                        echo "National Level (Full Access)";
                    }
                    ?>
                </div>
            </div>
            <a href="logout.php" class="logout-btn">
                <i class="fas fa-sign-out-alt"></i>
                Logout
            </a>
        </div>
    </div>

    <div class="dashboard-container">
        <!-- Statistics Grid - Now with only 2 cards -->
        <div class="stats-grid">
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-users"></i>
                </div>
                <div class="stat-number"><?php echo $total_officers; ?></div>
                <div class="stat-label">Total Officers</div>
            </div>
            <div class="stat-card">
                <div class="stat-icon">
                    <i class="fas fa-star"></i>
                </div>
                <div class="stat-number"><?php echo $total_abilities; ?></div>
                <div class="stat-label">Officer Abilities</div>
            </div>
        </div>

        <!-- Search Section -->
        <div class="search-section">
            <h3><i class="fas fa-search"></i> Search Officer Abilities</h3>
            <form method="GET" class="search-form">
                <input type="text" name="search" class="search-input" 
                       placeholder="Search by ability name, officer name, or position..." 
                       value="<?php echo htmlspecialchars($search_term); ?>">
                <button type="submit" class="search-btn">
                    <i class="fas fa-search"></i>
                    Search Abilities
                </button>
                <?php if ($show_search_results && !empty($abilities)): ?>
                <button type="button" class="print-btn" onclick="window.print()">
                    <i class="fas fa-print"></i>
                    Print Report
                </button>
                <?php endif; ?>
            </form>
            <div class="stats-info">
                <div class="stat-badge">
                    <i class="fas fa-database"></i> Total Abilities: <?php echo $total_abilities; ?>
                </div>
                <?php if ($show_search_results): ?>
                <div class="stat-badge">
                    <i class="fas fa-list"></i> Showing: <?php echo count($abilities); ?> results
                </div>
                <?php if (!empty($search_term)): ?>
                <div class="stat-badge">
                    <i class="fas fa-filter"></i> Search: "<?php echo htmlspecialchars($search_term); ?>"
                </div>
                <?php endif; ?>
                <?php endif; ?>
                <div class="access-badge">
                    <i class="fas fa-shield-alt"></i>
                    <?php 
                    if ($admin_dsid) {
                        echo "Viewing: " . htmlspecialchars($admin_division_name);
                    } elseif ($admin_district_id) {
                        echo "Viewing: District Level Data";
                    } else {
                        echo "Viewing: National Level Data";
                    }
                    ?>
                </div>
            </div>
        </div>

        <!-- Abilities Results Section -->
        <div class="abilities-section">
            <div class="section-header">
                <h3><i class="fas fa-tasks"></i> Officer Abilities</h3>
            </div>

            <?php if ($show_search_results): ?>
                <?php if (empty($abilities)): ?>
                    <div class="no-results">
                        <div class="empty-icon">
                            <i class="fas fa-inbox"></i>
                        </div>
                        <h3>No abilities found</h3>
                        <p><?php echo empty($search_term) ? 'No abilities have been added by officers in your assigned area yet.' : 'No abilities found matching your search criteria in your assigned area.'; ?></p>
                    </div>
                <?php else: ?>
                    <div class="table-container">
                        <table class="abilities-table">
                            <thead>
                                <tr>
                                    <th>Ability</th>
                                    <th>Where Used</th>
                                    <th>Officer</th>
                                    <th>Contact</th>
                                    <th>Location</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($abilities as $ability): ?>
                                    <tr>
                                        <td>
                                            <div class="ability-name"><?php echo htmlspecialchars($ability['ability_name']); ?></div>
                                        </td>
                                        <td>
                                            <div class="where-used">
                                                <?php echo !empty($ability['where_used']) ? htmlspecialchars($ability['where_used']) : '<em>Not specified</em>'; ?>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="officer-info">
                                                <div class="officer-name"><?php echo htmlspecialchars($ability['officer_name']); ?></div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="contact-info">
                                                <div class="contact-item">
                                                    <i class="fas fa-envelope"></i>
                                                    <?php echo htmlspecialchars($ability['email']); ?>
                                                </div>
                                                <div class="contact-item">
                                                    <i class="fas fa-phone"></i>
                                                    <?php echo htmlspecialchars($ability['Contact'] ?? 'Not provided'); ?>
                                                </div>
                                            </div>
                                        </td>
                                        <td>
                                            <div class="location-info">
                                                <div class="location-item">
                                                    <i class="fas fa-building"></i>
                                                    <?php echo htmlspecialchars($ability['division'] ?? 'Not assigned'); ?>
                                                </div>
                                                <div class="location-item">
                                                    <i class="fas fa-map"></i>
                                                    <?php echo htmlspecialchars($ability['district'] ?? 'Not assigned'); ?>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
            <?php else: ?>
                <div class="no-search">
                    <div class="empty-icon">
                        <i class="fas fa-search"></i>
                    </div>
                    <h3>Search Officer Abilities</h3>
                    <p>Use the search form above to find abilities by name, officer, or position within your assigned administrative area.</p>
                    <?php if ($admin_dsid): ?>
                        <p><strong>Your access:</strong> You can only view data from <?php echo htmlspecialchars($admin_division_name); ?>.</p>
                    <?php elseif ($admin_district_id): ?>
                        <p><strong>Your access:</strong> You can only view data from your assigned district.</p>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <script>
        // Print functionality
        function printReport() {
            window.print();
        }

        // Add keyboard shortcut for print (Ctrl + P)
        document.addEventListener('keydown', function(e) {
            if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
                e.preventDefault();
                window.print();
            }
        });

        // Debug: Check if page loaded properly
        console.log('Admin dashboard loaded successfully');
        console.log('Admin access level:', '<?php echo $admin_dsid ? "Division Level" : ($admin_district_id ? "District Level" : "National Level"); ?>');
    </script>
</body>
</html>