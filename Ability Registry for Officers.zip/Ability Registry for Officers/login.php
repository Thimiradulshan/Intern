<?php
session_start();
require_once 'connection.php';

header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);
    
    if (empty($username) || empty($password)) {
        echo json_encode(['success' => false, 'message' => 'Please enter both username and password']);
        exit;
    }
    
    try {
        // Check in user table only
        $stmt = $pdo->prepare("SELECT * FROM user WHERE Username = ?");
        $stmt->execute([$username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($user) {
            // Check officer password - try both Password and password2 fields
            if ($password === $user['Password'] || $password === $user['password2']) {
                
                // Clear any existing session
                session_regenerate_id(true);
                
                // Set session variables
                $_SESSION['user_id'] = $user['ID'];
                $_SESSION['username'] = $user['Username'];
                $_SESSION['name'] = $user['Name'];
                $_SESSION['role'] = $user['role'] ?? 'officer';
                $_SESSION['email'] = $user['email'];
                $_SESSION['dsid'] = $user['dsid'];
                $_SESSION['district_id'] = $user['district_id'];
                $_SESSION['province_id'] = $user['Province_id'];
                $_SESSION['position'] = $user['Position'];
                $_SESSION['contact'] = $user['Contact'];
                $_SESSION['logged_in'] = true;
                
                // Force session write
                session_write_close();
                
                // Debug output
                error_log("Login successful - User: " . $user['Username'] . ", Role: " . $user['role'] . ", Session ID: " . session_id());
                
                // Check for Admin role (case-insensitive)
                $userRole = strtolower(trim($user['role']));
                $isAdmin = ($userRole === 'admin');
                
                echo json_encode([
                    'success' => true, 
                    'role' => $isAdmin ? 'admin' : 'officer',
                    'actual_role' => $user['role'],
                    'user_id' => $user['ID'],
                    'message' => 'Login successful! Redirecting...'
                ]);
                exit;
            } else {
                echo json_encode(['success' => false, 'message' => 'Invalid password']);
                exit;
            }
        } else {
            echo json_encode(['success' => false, 'message' => 'Username not found']);
            exit;
        }
        
    } catch (PDOException $e) {
        error_log("Login error: " . $e->getMessage());
        echo json_encode(['success' => false, 'message' => 'Database error. Please try again.']);
        exit;
    }
} else {
    echo json_encode(['success' => false, 'message' => 'Invalid request method']);
    exit;
}
?>