<?php
// accountant/issue_item.php
session_start();
include('../db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Accountant') {
    header("Location: ../login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: dashboard.php");
    exit();
}

$request_id = intval($_POST['request_id'] ?? 0);
$officer_id = intval($_POST['officer_id'] ?? 0);
$item_id = intval($_POST['item_id'] ?? 0);
$issue_qty = intval($_POST['issue_qty'] ?? 0);

if ($request_id <= 0 || $officer_id <= 0 || $item_id <= 0 || $issue_qty <= 0) {
    $_SESSION['msg'] = "Invalid data submitted.";
    header("Location: dashboard.php");
    exit();
}

// Start transaction
$conn->begin_transaction();

try {
    // 1) Check current stock and requested request existence
    $stmt = $conn->prepare("SELECT Quantity, Unit_Price FROM items WHERE Item_ID = ? FOR UPDATE");
    $stmt->bind_param("i", $item_id);
    $stmt->execute();
    $res = $stmt->get_result();
    if ($res->num_rows === 0) throw new Exception("Item not found.");
    $item = $res->fetch_assoc();
    $stock_qty = (int)$item['Quantity'];
    $unit_price = (float)$item['Unit_Price'];

    if ($issue_qty > $stock_qty) throw new Exception("Not enough stock to issue.");

    // 2) Insert into issued_items
    $stmt2 = $conn->prepare("INSERT INTO issued_items (Request_ID, Officer_ID, Item_ID, Quantity) VALUES (?, ?, ?, ?)");
    $stmt2->bind_param("iiii", $request_id, $officer_id, $item_id, $issue_qty);
    $stmt2->execute();

    // 3) Decrease stock in items table
    $new_stock = $stock_qty - $issue_qty;
    $stmt3 = $conn->prepare("UPDATE items SET Quantity = ? WHERE Item_ID = ?");
    $stmt3->bind_param("ii", $new_stock, $item_id);
    $stmt3->execute();

    // 4) Update officer_limit.used_amount (increase used amount)
    // If officer_limit row exists, update; if not, create with used amount = issue value
    $issue_value = $unit_price * $issue_qty;

    $stmt4 = $conn->prepare("SELECT Limit_ID, Used_Amount FROM officer_limit WHERE Officer_ID = ? FOR UPDATE");
    $stmt4->bind_param("i", $officer_id);
    $stmt4->execute();
    $res4 = $stmt4->get_result();

    if ($res4->num_rows > 0) {
        $ol = $res4->fetch_assoc();
        $limit_id = (int)$ol['Limit_ID'];
        $old_used = (float)$ol['Used_Amount'];
        $new_used = $old_used + $issue_value;
        $stmt5 = $conn->prepare("UPDATE officer_limit SET Used_Amount = ? WHERE Limit_ID = ?");
        $stmt5->bind_param("di", $new_used, $limit_id);
        $stmt5->execute();
    } else {
        // Insert a new officer_limit row with zero annual limit and used amount = issue_value
        $stmt6 = $conn->prepare("INSERT INTO officer_limit (Officer_ID, Annual_Limit, Used_Amount) VALUES (?, ?, ?)");
        $zero = 0.00;
        $stmt6->bind_param("idd", $officer_id, $zero, $issue_value);
        $stmt6->execute();
    }

    // 5) Optionally mark the request as 'Issued' — but enum doesn't have 'Issued'.
    // We'll keep Status='Approved' and rely on issued_items existence to mean issued.
    // Or update a 'processed' flag if you added such column. For now we do nothing.

    $conn->commit();
    $_SESSION['msg_success'] = "Issued successfully. Stock and officer usage updated.";
    header("Location: dashboard.php");
    exit();

} catch (Exception $ex) {
    $conn->rollback();
    $_SESSION['msg_error'] = "Issue failed: " . $ex->getMessage();
    header("Location: dashboard.php");
    exit();
}