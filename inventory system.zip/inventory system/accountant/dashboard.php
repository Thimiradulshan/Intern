<?php
session_start();
include('../db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Accountant') {
    header("Location: ../login.php");
    exit();
}

$name = $_SESSION['name'];

// ✅ Approved requests that are NOT yet issued
$sql = "
  SELECT ir.Request_ID, ir.Officer_ID, u.Name AS Officer_Name,
         i.Item_ID, i.Item_Name, i.Quantity AS Stock_Qty, ir.Quantity AS Req_Qty, ir.Request_Date
  FROM item_requests ir
  JOIN users u ON ir.Officer_ID = u.ID
  JOIN items i ON ir.Item_ID = i.Item_ID
  LEFT JOIN issued_items iss ON iss.Request_ID = ir.Request_ID
  WHERE ir.Status = 'Approved' AND iss.Issue_ID IS NULL
  ORDER BY ir.Request_Date DESC
";
$pendingReqs = $conn->query($sql);

// ✅ Issued items history
$issued_sql = "
  SELECT iss.Issue_ID, iss.Request_ID, u.Name AS Officer_Name, it.Item_Name,
         iss.Quantity, iss.Issue_Date, (it.Unit_Price * iss.Quantity) AS TotalValue
  FROM issued_items iss
  JOIN users u ON iss.Officer_ID = u.ID
  JOIN items it ON iss.Item_ID = it.Item_ID
  ORDER BY iss.Issue_Date DESC
  LIMIT 200
";
$issuedHistory = $conn->query($issued_sql);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Accountant Dashboard | Inventory</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Bootstrap -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background:#f6f9ff; font-family: Inter, system-ui, Arial; }
    .hero { background:#fff; padding:16px 20px; border-radius:10px; box-shadow:0 6px 18px rgba(22,44,88,0.06); }
    .small-muted { font-size:0.9rem; color:#6b7280; }
    .table-card { background:#fff; border-radius:10px; padding:18px; box-shadow:0 6px 18px rgba(22,44,88,0.04); }
  </style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-light" style="background:linear-gradient(90deg,#ffffff,#e9f0ff);">
  <div class="container">
    <a class="navbar-brand fw-bold" href="#">Inventory — Accountant</a>
    <div class="d-flex align-items-center ms-auto">
      <div class="me-3 small-muted">Welcome, <?php echo htmlspecialchars($name); ?></div>
      <form action="../logout.php" method="POST">
        <button class="btn btn-outline-secondary btn-sm">Logout</button>
      </form>
    </div>
  </div>
</nav>

<div class="container py-4">
  <div class="hero d-flex justify-content-between align-items-center mb-4">
    <div>
      <h4 class="mb-1">Accountant Dashboard</h4>
      <div class="small-muted">Issue approved item requests and track issued stock</div>
    </div>
  </div>

  <!-- Pending Approved Requests -->
  <div class="table-card mb-4">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h5 class="mb-0">Approved Requests (Pending Issue)</h5>
      <div class="small-muted">Only approved requests that are not yet issued show here</div>
    </div>

    <div class="table-responsive">
      <table class="table table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th>Officer</th>
            <th>Item</th>
            <th>Requested</th>
            <th>Stock</th>
            <th>Requested Date</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($pendingReqs->num_rows == 0) { ?>
            <tr><td colspan="6" class="text-center small-muted">No approved requests waiting to be issued.</td></tr>
          <?php } else { while ($r = $pendingReqs->fetch_assoc()) { ?>
            <tr>
              <td><?php echo htmlspecialchars($r['Officer_Name']); ?></td>
              <td><?php echo htmlspecialchars($r['Item_Name']); ?></td>
              <td><?php echo (int)$r['Req_Qty']; ?></td>
              <td><?php echo (int)$r['Stock_Qty']; ?></td>
              <td><?php echo date('Y-m-d', strtotime($r['Request_Date'])); ?></td>
              <td>
                <button class="btn btn-sm btn-info me-1"
                  onclick="openIssueModal(<?php echo $r['Request_ID']; ?>,<?php echo $r['Officer_ID']; ?>,<?php echo $r['Item_ID']; ?>,
                  '<?php echo addslashes($r['Officer_Name']); ?>','<?php echo addslashes($r['Item_Name']); ?>',
                  <?php echo (int)$r['Req_Qty']; ?>,<?php echo (int)$r['Stock_Qty']; ?>)">Issue</button>
              </td>
            </tr>
          <?php } } ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Issued History -->
  <div class="table-card">
    <div class="d-flex justify-content-between align-items-center mb-3">
      <h5 class="mb-0">Recently Issued Items</h5>
      <div class="small-muted"><?php echo $issuedHistory->num_rows; ?> records</div>
    </div>
    <div class="table-responsive">
      <table class="table table-sm table-striped">
        <thead class="table-secondary">
          <tr>
            <th>Issue ID</th>
            <th>Officer</th>
            <th>Item</th>
            <th>Qty</th>
            <th>Value (Rs.)</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($issuedHistory->num_rows == 0) { ?>
            <tr><td colspan="6" class="text-center small-muted">No issued history yet.</td></tr>
          <?php } else { while ($row = $issuedHistory->fetch_assoc()) { ?>
            <tr>
              <td><?php echo $row['Issue_ID']; ?></td>
              <td><?php echo htmlspecialchars($row['Officer_Name']); ?></td>
              <td><?php echo htmlspecialchars($row['Item_Name']); ?></td>
              <td><?php echo (int)$row['Quantity']; ?></td>
              <td><?php echo number_format($row['TotalValue'],2); ?></td>
              <td><?php echo date('Y-m-d H:i', strtotime($row['Issue_Date'])); ?></td>
            </tr>
          <?php } } ?>
        </tbody>
      </table>
    </div>
  </div>
</div>

<!-- Issue Modal -->
<div class="modal fade" id="issueModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <form method="POST" action="issue_item.php" id="issueForm">
        <div class="modal-header">
          <h5 class="modal-title">Issue Item</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>
        <div class="modal-body">
          <input type="hidden" name="request_id" id="m_request_id">
          <input type="hidden" name="officer_id" id="m_officer_id">
          <input type="hidden" name="item_id" id="m_item_id">

          <div class="mb-2">
            <label class="form-label">Officer</label>
            <input type="text" class="form-control" id="m_officer_name" readonly>
          </div>

          <div class="mb-2">
            <label class="form-label">Item</label>
            <input type="text" class="form-control" id="m_item_name" readonly>
          </div>

          <div class="row g-2">
            <div class="col-6">
              <label class="form-label">Requested Qty</label>
              <input type="number" class="form-control" id="m_req_qty" readonly>
            </div>
            <div class="col-6">
              <label class="form-label">Stock Available</label>
              <input type="number" class="form-control" id="m_stock_qty" readonly>
            </div>
          </div>

          <div class="mt-3">
            <label class="form-label">Qty to Issue</label>
            <input type="number" name="issue_qty" id="m_issue_qty" class="form-control" min="1" required>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary btn-sm" data-bs-dismiss="modal">Cancel</button>
          <button type="submit" class="btn btn-primary btn-sm">Confirm Issue</button>
        </div>
      </form>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>

<script>
function openIssueModal(requestId, officerId, itemId, officerName, itemName, reqQty, stockQty){
  document.getElementById('m_request_id').value = requestId;
  document.getElementById('m_officer_id').value = officerId;
  document.getElementById('m_item_id').value = itemId;
  document.getElementById('m_officer_name').value = officerName;
  document.getElementById('m_item_name').value = itemName;
  document.getElementById('m_req_qty').value = reqQty;
  document.getElementById('m_stock_qty').value = stockQty;
  document.getElementById('m_issue_qty').value = Math.min(reqQty, stockQty);
  var modal = new bootstrap.Modal(document.getElementById('issueModal'));
  modal.show();
}

document.getElementById('issueForm').addEventListener('submit', function(e){
  var stock = parseInt(document.getElementById('m_stock_qty').value);
  var issue = parseInt(document.getElementById('m_issue_qty').value);
  if (issue > stock){
    e.preventDefault();
    alert('Cannot issue more than available stock.');
  }
});
</script>

</body>
</html>