<?php
include('../db.php');
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../login.php");
    exit();
}

// ✅ Corrected SQL (joined with "users" table)
$sql = "SELECT ir.Request_ID, u.Name AS Officer_Name, u.section_id, i.Item_Name, ir.Quantity, ir.Status, ir.Request_Date
        FROM item_requests ir
        JOIN users u ON ir.Officer_ID = u.ID
        JOIN items i ON ir.Item_ID = i.Item_ID
        ORDER BY ir.Request_Date DESC";
$result = $conn->query($sql);

// ✅ Optional: if you want to show the actual Section name instead of section_id
$sections = [];
$secResult = $conn->query("SELECT section_id, section_name FROM sections");
while ($s = $secResult->fetch_assoc()) {
    $sections[$s['section_id']] = $s['section_name'];
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>View Item Requests | Admin Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
body {
    font-family: 'Inter', sans-serif;
    background: #f7faff;
    margin: 0;
    padding: 0;
}
header {
    background: linear-gradient(90deg, #007bff, #0044cc);
    color: white;
    padding: 18px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
header h2 { margin: 0; font-weight: 600; }
.logout-btn {
    background: white;
    color: #007bff;
    border: none;
    padding: 8px 16px;
    border-radius: 8px;
    font-weight: 500;
    cursor: pointer;
}
.logout-btn:hover { background: #f0f0f0; }

.container {
    width: 90%;
    margin: 40px auto;
    background: white;
    border-radius: 12px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    padding: 30px;
}
h3 {
    text-align: center;
    color: #007bff;
    margin-bottom: 20px;
}
.filter-box {
    text-align: right;
    margin-bottom: 15px;
}
select {
    padding: 8px 12px;
    border: 1px solid #ccc;
    border-radius: 8px;
    font-size: 14px;
}
table {
    width: 100%;
    border-collapse: collapse;
}
th, td {
    padding: 12px;
    border-bottom: 1px solid #eee;
    text-align: center;
}
th {
    background: #007bff;
    color: white;
}
tr:hover {
    background: #f9f9ff;
}
.status {
    padding: 6px 12px;
    border-radius: 8px;
    font-weight: 600;
    font-size: 13px;
}
.Pending { background: #fff3cd; color: #856404; }
.Approved { background: #d4edda; color: #155724; }
.Rejected { background: #f8d7da; color: #721c24; }
.back-btn {
    display: inline-block;
    background: #007bff;
    color: white;
    padding: 10px 16px;
    border-radius: 8px;
    text-decoration: none;
    font-weight: 500;
}
.back-btn:hover {
    background: #0056b3;
}
</style>
</head>
<body>

<header>
    <h2>📋 View Item Requests</h2>
    <form action="../logout.php" method="POST">
        <button class="logout-btn">Logout</button>
    </form>
</header>

<div class="container">
    <a href="dashboard.php" class="back-btn"><i class="fa fa-arrow-left"></i> Back to Dashboard</a>

    <h3>All Item Requests</h3>

    <div class="filter-box">
        <label for="statusFilter"><strong>Filter by Status:</strong></label>
        <select id="statusFilter" onchange="filterTable()">
            <option value="All">All</option>
            <option value="Pending">Pending</option>
            <option value="Approved">Approved</option>
            <option value="Rejected">Rejected</option>
        </select>
    </div>

    <table id="requestsTable">
        <thead>
            <tr>
                <th>Officer</th>
                <th>Section</th>
                <th>Item</th>
                <th>Quantity</th>
                <th>Status</th>
                <th>Date</th>
            </tr>
        </thead>
        <tbody>
            <?php while($row = $result->fetch_assoc()) { ?>
            <tr>
                <td><?= htmlspecialchars($row['Officer_Name']) ?></td>
                <td>
                    <?= isset($sections[$row['section_id']]) ? htmlspecialchars($sections[$row['section_id']]) : 'N/A' ?>
                </td>
                <td><?= htmlspecialchars($row['Item_Name']) ?></td>
                <td><?= $row['Quantity'] ?></td>
                <td><span class="status <?= $row['Status'] ?>"><?= $row['Status'] ?></span></td>
                <td><?= date("Y-m-d", strtotime($row['Request_Date'])) ?></td>
            </tr>
            <?php } ?>
        </tbody>
    </table>
</div>

<script>
function filterTable() {
    const filter = document.getElementById("statusFilter").value.toLowerCase();
    const rows = document.querySelectorAll("#requestsTable tbody tr");

    rows.forEach(row => {
        const status = row.querySelector("td:nth-child(5)").innerText.toLowerCase();
        if (filter === "all" || status === filter) {
            row.style.display = "";
        } else {
            row.style.display = "none";
        }
    });
}
</script>

</body>
</html>