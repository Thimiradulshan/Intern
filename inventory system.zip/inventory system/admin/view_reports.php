<?php
// admin/reports.php
session_start();
include('../db.php');

// ✅ Check if logged in as Admin
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Admin') {
    header("Location: ../login.php");
    exit();
}

$name = $_SESSION['name'];

// Clerk (DS Officer) approvals report
$approvals_sql = "
  SELECT a.Approval_ID, a.Request_ID, u.Name AS DS_Officer, a.Approval_Status, a.Approval_Date,
         ir.Item_ID, i.Item_Name, ir.Quantity, ir.Request_Date, off.Name AS Requesting_Officer
  FROM approvals a
  JOIN item_requests ir ON a.Request_ID = ir.Request_ID
  JOIN users u ON a.DS_Officer_ID = u.ID
  JOIN users off ON ir.Officer_ID = off.ID
  JOIN items i ON ir.Item_ID = i.Item_ID
  ORDER BY a.Approval_Date DESC
";
$approvals = $conn->query($approvals_sql);

// Accountant issues report
$issues_sql = "
  SELECT iss.Issue_ID, iss.Request_ID, off.Name AS Officer_Name, i.Item_Name, iss.Quantity, iss.Issue_Date
  FROM issued_items iss
  JOIN users off ON iss.Officer_ID = off.ID
  JOIN items i ON iss.Item_ID = i.Item_ID
  ORDER BY iss.Issue_Date DESC
";
$issues = $conn->query($issues_sql);
?>
<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Admin Reports | Inventory System</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body { background:#f7faff; font-family: 'Inter', sans-serif; }
    .container { max-width: 1200px; }
    .card { border-radius:10px; box-shadow:0 4px 12px rgba(0,0,0,0.05); margin-bottom:20px; }
    .header-bar { background:#0d6efd; color:white; padding:15px 25px; }
    .btn-back {
      background:white; border:none; color:#0d6efd; font-weight:500;
      border-radius:8px; padding:6px 14px; text-decoration:none;
      box-shadow:0 2px 4px rgba(0,0,0,0.1);
    }
    .btn-back:hover { background:#f0f5ff; }
    table thead { background:#e8f0ff; }
  </style>
</head>
<body>

<nav class="header-bar d-flex justify-content-between align-items-center">
  <h4 class="m-0">📊 Inventory System — Admin Reports</h4>
  <div>
    <span class="me-3">👤 <?php echo htmlspecialchars($name); ?></span>
    <a href="../logout.php" class="btn btn-light btn-sm">Logout</a>
  </div>
</nav>

<div class="container mt-4">

  <!-- 🔙 Back to Dashboard -->
  <div class="mb-3">
    <a href="dashboard.php" class="btn-back">← Back to Dashboard</a>
  </div>

  <!-- Clerk (DS Officer) Approvals Report -->
  <div class="card">
    <div class="card-header bg-primary text-white d-flex justify-content-between">
      <h5 class="m-0">DS Officer Approvals Report</h5>
      <small>All Approved / Rejected Requests</small>
    </div>
    <div class="card-body table-responsive">
      <table class="table table-hover align-middle">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Request ID</th>
            <th>Requested By</th>
            <th>Item</th>
            <th>Qty</th>
            <th>Status</th>
            <th>Approved By</th>
            <th>Date</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($approvals->num_rows == 0) { ?>
            <tr><td colspan="8" class="text-center text-muted">No approvals recorded.</td></tr>
          <?php } else { $i=1; while($r=$approvals->fetch_assoc()){ ?>
            <tr>
              <td><?php echo $i++; ?></td>
              <td>#<?php echo $r['Request_ID']; ?></td>
              <td><?php echo htmlspecialchars($r['Requesting_Officer']); ?></td>
              <td><?php echo htmlspecialchars($r['Item_Name']); ?></td>
              <td><?php echo (int)$r['Quantity']; ?></td>
              <td>
                <?php if($r['Approval_Status']=='Approved'){ ?>
                  <span class="badge bg-success">Approved</span>
                <?php } else { ?>
                  <span class="badge bg-danger">Rejected</span>
                <?php } ?>
              </td>
              <td><?php echo htmlspecialchars($r['DS_Officer']); ?></td>
              <td><?php echo date('Y-m-d H:i', strtotime($r['Approval_Date'])); ?></td>
            </tr>
          <?php } } ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Accountant Issued Items Report -->
  <div class="card">
    <div class="card-header bg-success text-white d-flex justify-content-between">
      <h5 class="m-0">Accountant Issued Items Report</h5>
      <small>All Issued Items History</small>
    </div>
    <div class="card-body table-responsive">
      <table class="table table-striped align-middle">
        <thead class="table-light">
          <tr>
            <th>#</th>
            <th>Issue ID</th>
            <th>Request ID</th>
            <th>Officer</th>
            <th>Item</th>
            <th>Quantity</th>
            <th>Issued Date</th>
          </tr>
        </thead>
        <tbody>
          <?php if ($issues->num_rows == 0) { ?>
            <tr><td colspan="7" class="text-center text-muted">No issued items yet.</td></tr>
          <?php } else { $j=1; while($r=$issues->fetch_assoc()){ ?>
            <tr>
              <td><?php echo $j++; ?></td>
              <td>#<?php echo $r['Issue_ID']; ?></td>
              <td>#<?php echo $r['Request_ID']; ?></td>
              <td><?php echo htmlspecialchars($r['Officer_Name']); ?></td>
              <td><?php echo htmlspecialchars($r['Item_Name']); ?></td>
              <td><?php echo (int)$r['Quantity']; ?></td>
              <td><?php echo date('Y-m-d H:i', strtotime($r['Issue_Date'])); ?></td>
            </tr>
          <?php } } ?>
        </tbody>
      </table>
    </div>
  </div>

</div>

</body>
</html>