<?php
include('../db.php');
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../login.php");
    exit();
}

// Add User
if (isset($_POST['add_user'])) {
    $name = $_POST['name'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $role = $_POST['role'];
    $position = $_POST['position'];
    $section_id = $_POST['section_id'];
    $email = $_POST['email'];

    $sql = "INSERT INTO user (Name, Username, Password, Role, Position, section_id, Email)
            VALUES (?, ?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sssssis", $name, $username, $password, $role, $position, $section_id, $email);
    $stmt->execute();
    header("Location: manage_users.php");
}

// Delete User
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM user WHERE ID=$id");
    header("Location: manage_users.php");
}

// FIXED: table name corrected
$users = $conn->query("SELECT u.*, s.section_name 
                       FROM users u 
                       LEFT JOIN sections s ON u.section_id = s.section_id");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Users | Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
  /* ===== Modern Theme for Manage Users Page ===== */
body {
  font-family: 'Inter', sans-serif;
  background: #f4f8ff;
  margin: 0;
  color: #333;
}

/* Header Section */
header {
  background: linear-gradient(90deg, #007bff, #0056b3);
  color: white;
  padding: 18px 40px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}
header h2 {
  margin: 0;
  font-weight: 600;
}
header a {
  background: white;
  color: #007bff;
  text-decoration: none;
  padding: 8px 15px;
  border-radius: 6px;
  font-weight: 500;
  transition: 0.3s;
}
header a:hover {
  background: #e9f2ff;
}

/* Main Container */
.container {
  padding: 40px;
}

/* Add Form Card */
form.add-form {
  background: white;
  padding: 25px 30px;
  border-radius: 10px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  margin-bottom: 30px;
  border-left: 6px solid #007bff;
}
form.add-form h3 {
  margin-bottom: 15px;
  color: #0056b3;
  font-weight: 600;
}
input, select {
  padding: 10px 12px;
  width: 220px;
  margin: 6px;
  border: 1px solid #ccd6f6;
  border-radius: 6px;
  font-size: 14px;
  transition: 0.2s;
}
input:focus, select:focus {
  border-color: #007bff;
  outline: none;
  box-shadow: 0 0 5px rgba(0, 123, 255, 0.3);
}

/* Buttons */
.btn {
  padding: 10px 18px;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  font-weight: 500;
  transition: 0.3s;
}
.add-btn {
  background: #007bff;
  color: white;
}
/* 🔹 Back to Dashboard Button Style */
.back-btn {
  background: #ffffff;
  color: #007bff;
  border: 2px solid #007bff;
  padding: 8px 18px;
  border-radius: 6px;
  font-weight: 500;
  text-decoration: none;
  transition: all 0.3s ease;
}

.back-btn:hover {
  background: #007bff;
  color: #ffffff;
  box-shadow: 0 2px 8px rgba(0, 123, 255, 0.3);
  text-decoration: none;
}
.add-btn:hover {
  background: #0056b3;
}
.del-btn {
  background: #dc3545;
  color: white;
}
.del-btn:hover {
  background: #b51e2e;
}

/* Table Styling */
table {
  width: 100%;
  border-collapse: collapse;
  background: white;
  border-radius: 10px;
  overflow: hidden;
  box-shadow: 0 3px 10px rgba(0, 0, 0, 0.08);
}
th, td {
  padding: 14px;
  text-align: center;
  border-bottom: 1px solid #e6e9f3;
  font-size: 14px;
}
th {
  background: #007bff;
  color: white;
  font-weight: 600;
}
tr:hover {
  background: #f2f7ff;
}
td button {
  font-size: 13px;
}

/* Responsive */
@media (max-width: 768px) {
  input, select {
    width: 100%;
  }
  form.add-form {
    padding: 20px;
  }
}
body {font-family:'Inter',sans-serif;background:#f4f7ff;margin:0;}
header {background:#007bff;color:white;padding:15px 30px;display:flex;justify-content:space-between;}
.container {padding:40px;}
table {width:100%;border-collapse:collapse;background:white;}
th,td{padding:12px;text-align:center;border-bottom:1px solid #ddd;}
th{background:#007bff;color:white;}
.btn{padding:8px 16px;border:none;border-radius:6px;cursor:pointer;}
.add-btn{background:#28a745;color:white;}
.del-btn{background:#dc3545;color:white;}
form.add-form{background:white;padding:20px;border-radius:10px;margin-bottom:25px;}
input,select{padding:10px;width:200px;margin:5px;border:1px solid #ccc;border-radius:6px;}
</style>
</head>
<body>
<header>
  <h2>Manage Users</h2>
  <a href="dashboard.php" class="back-btn">← Back to Dashboard</a>
</header>

<div class="container">
  <form method="POST" class="add-form">
    <h3>Add New User</h3>
    <input type="text" name="name" placeholder="Full Name" required>
    <input type="text" name="username" placeholder="Username" required>
    <input type="password" name="password" placeholder="Password" required>
    <select name="role" required>
        <option value="">Select Role</option>
        <option value="Admin">Admin</option>
        <option value="DS_Officer">DS Officer</option>
        <option value="Accountant">Accountant</option>
        <option value="Officer">Officer</option>
    </select>
    <input type="text" name="position" placeholder="Position">

    <!-- Section dropdown from sections table -->
    <select name="section_id">
        <option value="">Select Section</option>
        <?php
        $result = $conn->query("SELECT * FROM sections");
        while ($row = $result->fetch_assoc()) {
            echo "<option value='{$row['section_id']}'>{$row['section_name']}</option>";
        }
        ?>
    </select>

    <input type="email" name="email" placeholder="Email">
    <button class="btn add-btn" name="add_user">Add User</button>
  </form>

  <table>
    <tr>
      <th>ID</th><th>Name</th><th>Username</th><th>Role</th><th>Position</th><th>Section</th><th>Email</th><th>Action</th>
    </tr>
    <?php while ($u = $users->fetch_assoc()) { ?>
    <tr>
      <td><?= $u['ID'] ?></td>
      <td><?= htmlspecialchars($u['Name']) ?></td>
      <td><?= $u['Username'] ?></td>
      <td><?= $u['Role'] ?></td>
      <td><?= $u['Position'] ?></td>
      <td><?= $u['section_name'] ?: 'N/A' ?></td>
      <td><?= $u['Email'] ?></td>
      <td><a href="?delete=<?= $u['ID'] ?>"><button class="btn del-btn">Delete</button></a></td>
    </tr>
    <?php } ?>
  </table>
</div>
</body>
</html>