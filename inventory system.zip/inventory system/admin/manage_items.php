<?php
include('../db.php');
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../login.php");
    exit();
}

// ADD ITEM
if (isset($_POST['add_item'])) {
    $name = $_POST['name'];
    $price = $_POST['price'];
    $qty = $_POST['qty'];

    // Image upload
    $image = null;
    if (!empty($_FILES['image']['name'])) {
        $target_dir = "../uploads/";
        if (!is_dir($target_dir)) {
            mkdir($target_dir, 0777, true);
        }

        $image_name = time() . "_" . basename($_FILES['image']['name']);
        $target_file = $target_dir . $image_name;

        if (move_uploaded_file($_FILES['image']['tmp_name'], $target_file)) {
            $image = $image_name;
        }
    }

    $sql = "INSERT INTO items (Item_Name, Unit_Price, Quantity, Image) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("sdis", $name, $price, $qty, $image);
    $stmt->execute();

    header("Location: manage_items.php");
    exit();
}

// DELETE ITEM
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $conn->query("DELETE FROM items WHERE Item_ID=$id");
    header("Location: manage_items.php");
    exit();
}

$items = $conn->query("SELECT * FROM items ORDER BY Date_Added DESC");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Manage Items | Admin</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<style>
body {
    font-family: 'Inter', sans-serif;
    background: #f0f6ff;
    margin: 0;
}
header {
    background: linear-gradient(90deg, #007bff, #0056b3);
    color: white;
    padding: 15px 30px;
    display: flex;
    justify-content: space-between;
    align-items: center;
}
header a {
    color: white;
    text-decoration: none;
    font-weight: 500;
}
.container {
    padding: 40px;
}
form.add-form {
    background: white;
    padding: 25px;
    border-radius: 10px;
    margin-bottom: 25px;
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
}
form.add-form h3 {
    margin-top: 0;
    color: #007bff;
}
input, select {
    padding: 10px;
    width: calc(25% - 12px);
    margin: 8px;
    border: 1px solid #ccc;
    border-radius: 6px;
}
input[type=file] {
    width: calc(30% - 12px);
}
.btn {
    padding: 10px 20px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
}
.add-btn {
    background: #007bff;
    color: white;
}
.add-btn:hover {
    background: #0056b3;
}
.del-btn {
    background: #dc3545;
    color: white;
}
.del-btn:hover {
    background: #b02a37;
}
table {
    width: 100%;
    border-collapse: collapse;
    background: white;
    border-radius: 10px;
    overflow: hidden;
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
}
th, td {
    padding: 12px;
    text-align: center;
    border-bottom: 1px solid #eee;
}
th {
    background: #007bff;
    color: white;
}
tr:hover {
    background: #f1f6ff;
}
.item-img {
    width: 60px;
    height: 60px;
    object-fit: cover;
    border-radius: 6px;
    border: 1px solid #ddd;
}
</style>
</head>
<body>
<header>
  <h2>🛒 Manage Items</h2>
  <a href="dashboard.php">⬅ Back to Dashboard</a>
</header>

<div class="container">
  <form method="POST" enctype="multipart/form-data" class="add-form">
    <h3>Add New Item</h3>
    <input type="text" name="name" placeholder="Item Name" required>
    <input type="number" step="0.01" name="price" placeholder="Unit Price" required>
    <input type="number" name="qty" placeholder="Quantity" required>
    <input type="file" name="image" accept="image/*" required>
    <button class="btn add-btn" name="add_item">Add Item</button>
  </form>

  <table>
    <tr>
      <th>Image</th>
      <th>Item Name</th>
      <th>Unit Price</th>
      <th>Quantity</th>
      <th>Total Value</th>
      <th>Date Added</th>
      <th>Action</th>
    </tr>
    <?php while($item = $items->fetch_assoc()) { ?>
    <tr>
      <td>
        <?php if(!empty($item['Image'])): ?>
          <img src="../uploads/<?= htmlspecialchars($item['Image']) ?>" class="item-img">
        <?php else: ?>
          <span style="color:#999;">No Image</span>
        <?php endif; ?>
      </td>
      <td><?= htmlspecialchars($item['Item_Name']) ?></td>
      <td>Rs. <?= number_format($item['Unit_Price'],2) ?></td>
      <td><?= $item['Quantity'] ?></td>
      <td>Rs. <?= number_format($item['Unit_Price']*$item['Quantity'],2) ?></td>
      <td><?= $item['Date_Added'] ?></td>
      <td><a href="?delete=<?= $item['Item_ID'] ?>"><button class="btn del-btn">Delete</button></a></td>
    </tr>
    <?php } ?>
  </table>
</div>
</body>
</html>