<?php
include('../db.php');
session_start();

if (!isset($_SESSION['user_id']) || $_SESSION['role'] != 'Admin') {
    header("Location: ../login.php");
    exit();
}

// ---- Dashboard Stats ---- //
$total_users = $conn->query("SELECT COUNT(*) AS count FROM users")->fetch_assoc()['count'];
$total_items = $conn->query("SELECT COUNT(*) AS count FROM items")->fetch_assoc()['count'];
$total_requests = $conn->query("SELECT COUNT(*) AS count FROM item_requests")->fetch_assoc()['count'];
$pending_requests = $conn->query("SELECT COUNT(*) AS count FROM item_requests WHERE Status='Pending'")->fetch_assoc()['count'];
$total_value = $conn->query("SELECT IFNULL(SUM(Unit_Price * Quantity),0) AS value FROM items")->fetch_assoc()['value'];

// ---- Handle Limit Assign ---- //
if (isset($_POST['assign_limit'])) {
    $officer_id = $_POST['officer_id'];
    $year = $_POST['year'];
    $period = $_POST['period'];
    $limit_amount = $_POST['limit_amount'];

    $check = $conn->prepare("SELECT * FROM officer_limit WHERE Officer_ID=? AND Year=? AND Period=?");
    $check->bind_param("iis", $officer_id, $year, $period);
    $check->execute();
    $result = $check->get_result();

    if ($result->num_rows > 0) {
        $update = $conn->prepare("UPDATE officer_limit SET Annual_Limit=? WHERE Officer_ID=? AND Year=? AND Period=?");
        $update->bind_param("diis", $limit_amount, $officer_id, $year, $period);
        $update->execute();
        $message = "✅ Officer limit updated successfully!";
    } else {
        $insert = $conn->prepare("INSERT INTO officer_limit (Officer_ID, Year, Period, Annual_Limit, Used_Amount) VALUES (?, ?, ?, ?, 0)");
        $insert->bind_param("iisd", $officer_id, $year, $period, $limit_amount);
        $insert->execute();
        $message = "✅ Officer limit assigned successfully!";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin Dashboard | Inventory System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">

<style>
  /* ======== Global Theme (Same as Officer Dashboard) ======== */
body {
    font-family: 'Inter', sans-serif;
    background: #f5f8ff;
    color: #333;
    margin: 0;
}

/* ======== Header Bar ======== */
header {
    background: linear-gradient(90deg, #007bff, #0056b3);
    color: #fff !important;
    padding: 15px 25px;
    box-shadow: 0 3px 8px rgba(0, 0, 0, 0.1);
}
header h2 {
    font-weight: 600;
    margin: 0;
}
header .btn-light {
    background: #fff;
    color: #0056b3;
    font-weight: 500;
    border-radius: 8px;
    transition: 0.3s;
}
header .btn-light:hover {
    background: #e8f0ff;
}

/* ======== Dashboard Cards ======== */
.card {
    border-radius: 14px;
    border: none;
    background: #ffffff;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    transition: 0.3s ease;
}
.card:hover {
    transform: translateY(-4px);
    box-shadow: 0 6px 18px rgba(0,0,0,0.12);
}
.card h3 i {
    color: #0056b3;
}
.card p {
    color: #555;
    margin-bottom: 4px;
}
.card h5 {
    color: #007bff;
    font-weight: 600;
}

/* ======== Section Titles ======== */
h4.text-primary {
    color: #0056b3 !important;
    font-weight: 600;
}

/* ======== Buttons ======== */
.btn-primary {
    background: linear-gradient(90deg, #007bff, #0056b3);
    border: none;
    border-radius: 10px;
    font-weight: 500;
    transition: 0.3s;
}
.btn-primary:hover {
    background: #004a99;
    transform: translateY(-2px);
}

.btn-outline-primary {
    color: #0056b3;
    border: 2px solid #007bff;
    border-radius: 8px;
    font-weight: 500;
    transition: 0.3s;
}
.btn-outline-primary:hover {
    background: linear-gradient(90deg, #007bff, #0056b3);
    color: white;
    border-color: transparent;
}

/* ======== Forms ======== */
.form-control, .form-select {
    border: 1px solid #ccd8ff;
    border-radius: 8px;
    transition: 0.2s;
}
.form-control:focus, .form-select:focus {
    border-color: #007bff;
    box-shadow: 0 0 4px rgba(0,123,255,0.3);
}

/* ======== Alert Box ======== */
.alert-success {
    background: #eafaf1;
    color: #0f6848;
    border: none;
    border-radius: 8px;
}

/* ======== Footer ======== */
footer {
    color: #777;
    font-size: 14px;
}
body { font-family: 'Inter', sans-serif; background: #f4f8ff; }
.card { border-radius: 10px; box-shadow: 0 4px 10px rgba(0,0,0,0.08); }
h3 { color: #007bff; }
.btn-primary { background: #007bff; border: none; }
.btn-primary:hover { background: #0056b3; }
</style>
</head>

<body>
<header class="bg-primary text-white py-3 px-4 d-flex justify-content-between align-items-center">
  <h2>Admin Dashboard 🧭</h2>
  <form action="../logout.php" method="POST">
    <button class="btn btn-light btn-sm">Logout</button>
  </form>
</header>

<div class="container my-4">

  <!-- Dashboard Stats -->
  <div class="row g-3 mb-4">
    <div class="col-md-2"><div class="card p-3 text-center"><h3><i class="fa-solid fa-users"></i></h3><p>Total Users</p><h5><?= $total_users; ?></h5></div></div>
    <div class="col-md-2"><div class="card p-3 text-center"><h3><i class="fa-solid fa-boxes-stacked"></i></h3><p>Total Items</p><h5><?= $total_items; ?></h5></div></div>
    <div class="col-md-2"><div class="card p-3 text-center"><h3><i class="fa-solid fa-file-invoice"></i></h3><p>Total Requests</p><h5><?= $total_requests; ?></h5></div></div>
    <div class="col-md-3"><div class="card p-3 text-center"><h3><i class="fa-solid fa-hourglass-half"></i></h3><p>Pending Requests</p><h5><?= $pending_requests; ?></h5></div></div>
    <div class="col-md-3"><div class="card p-3 text-center"><h3><i class="fa-solid fa-sack-dollar"></i></h3><p>Total Value</p><h5>Rs. <?= number_format($total_value,2); ?></h5></div></div>
  </div>

  <!-- Assign Officer Limit -->
  <div class="card p-4 mb-4">
    <h4 class="text-primary"><i class="fa-solid fa-money-check-dollar"></i> Assign Officer Limit</h4>
    <?php if(isset($message)) echo "<div class='alert alert-success'>$message</div>"; ?>
    
    <form method="POST" class="row g-3">
      <div class="col-md-3">
        <label class="form-label">Officer</label>
        <select name="officer_id" class="form-select" required>
          <option value="">Select Officer</option>
          <?php
          $officers = $conn->query("SELECT ID, Name FROM users WHERE Role='officer'");
          while($o = $officers->fetch_assoc()) {
              echo "<option value='{$o['ID']}'>{$o['Name']}</option>";
          }
          ?>
        </select>
      </div>
      <div class="col-md-2">
        <label class="form-label">Year</label>
        <input type="number" name="year" class="form-control" value="<?= date('Y'); ?>" required>
      </div>
      <div class="col-md-3">
        <label class="form-label">Period</label>
        <select name="period" class="form-select" required>
          <option value="First_Half">First Half (Jan–Jun)</option>
          <option value="Second_Half">Second Half (Jul–Dec)</option>
        </select>
      </div>
      <div class="col-md-3">
        <label class="form-label">Limit Amount (Rs)</label>
        <input type="number" name="limit_amount" class="form-control" step="0.01" required>
      </div>
      <div class="col-md-1 d-flex align-items-end">
        <button type="submit" name="assign_limit" class="btn btn-primary w-100">Save</button>
      </div>
    </form>
  </div>

  <!-- Navigation Buttons -->
  <div class="text-center">
    <a href="manage_users.php" class="btn btn-outline-primary m-1"><i class="fa fa-user-cog"></i> Manage Users</a>
    <a href="manage_items.php" class="btn btn-outline-primary m-1"><i class="fa fa-box"></i> Manage Items</a>
    <a href="view_requests.php" class="btn btn-outline-primary m-1"><i class="fa fa-list"></i> View Requests</a>
    <a href="view_reports.php" class="btn btn-outline-primary m-1"><i class="fa fa-chart-line"></i> View Reports</a>
  </div>

</div>

<footer class="text-center text-muted mt-4 mb-3">
  © 2025 AG Office Inventory System 
</footer>

</body>
</html>