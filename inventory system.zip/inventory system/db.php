<?php
$servername = "localhost";
$username = "root";
$password = "";
$database = "divisional_secretariat_inventory";

$conn = new mysqli($servername, $username, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>