<?php
session_start();
include('../db.php');

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'DS_Officer') {
    header("Location: ../login.php");
    exit();
}

$ds_id = $_SESSION['user_id'];
$name  = $_SESSION['name'];

// ✅ Pending Requests
$pending_sql = "
    SELECT ir.Request_ID, ir.Officer_ID, u.Name AS Officer_Name, 
           s.section_name AS Section, i.Item_Name, ir.Quantity, ir.Request_Date
    FROM item_requests ir
    JOIN users u ON ir.Officer_ID = u.ID
    LEFT JOIN sections s ON u.section_id = s.section_id
    JOIN items i ON ir.Item_ID = i.Item_ID
    WHERE ir.Status = 'Pending'
    ORDER BY ir.Request_Date DESC
";
$pending = $conn->query($pending_sql);

// ✅ History (Approved / Rejected)
$history_sql = "
    SELECT ir.Request_ID, u.Name AS Officer_Name, 
           i.Item_Name, ir.Quantity, ir.Status, ir.Request_Date
    FROM item_requests ir
    JOIN users u ON ir.Officer_ID = u.ID
    JOIN items i ON ir.Item_ID = i.Item_ID
    WHERE ir.Status IN ('Approved','Rejected')
    ORDER BY ir.Request_Date DESC
";
$history = $conn->query($history_sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>DS Officer Dashboard | Inventory System</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" rel="stylesheet">
<style>
body {
    background: #f5f8ff;
    font-family: 'Segoe UI', sans-serif;
}
.navbar {
    background: linear-gradient(90deg, #0d6efd, #004aad);
}
.navbar-brand { font-weight: 600; }
.table thead {
    background: #0d6efd;
    color: white;
}
.status {
    padding: 5px 10px;
    border-radius: 8px;
    font-weight: 500;
    font-size: 0.9rem;
}
.status.Pending { background: #fff3cd; color: #856404; }
.status.Approved { background: #d4edda; color: #155724; }
.status.Rejected { background: #f8d7da; color: #721c24; }
.card {
    box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    border-radius: 10px;
}
.btn-info {
    background: #17a2b8;
    border: none;
}
.btn-info:hover {
    background: #138496;
}
</style>
</head>
<body>

<nav class="navbar navbar-expand-lg navbar-dark">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">📋 DS Officer Dashboard</a>
    <div class="d-flex align-items-center">
      <span class="text-white me-3">
        Welcome, <strong><?php echo htmlspecialchars($name); ?></strong>
      </span>
      <form action="../logout.php" method="POST" class="m-0">
        <button class="btn btn-light btn-sm">Logout</button>
      </form>
    </div>
  </div>
</nav>

<div class="container py-4">

  <!-- Pending Requests -->
  <div class="card mb-4">
    <div class="card-header bg-primary text-white">
      <h5 class="mb-0"><i class="fa-solid fa-hourglass-half"></i> Pending Requests</h5>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table align-middle">
          <thead>
            <tr>
              <th>Officer</th>
              <th>Section</th>
              <th>Item</th>
              <th>Qty</th>
              <th>Date</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($pending->num_rows > 0) { 
              while ($row = $pending->fetch_assoc()) { ?>
              <tr>
                <td><?= htmlspecialchars($row['Officer_Name']) ?></td>
                <td><?= htmlspecialchars($row['Section'] ?? 'N/A') ?></td>
                <td><?= htmlspecialchars($row['Item_Name']) ?></td>
                <td><?= $row['Quantity'] ?></td>
                <td><?= date('Y-m-d', strtotime($row['Request_Date'])) ?></td>
                <td>
                  <button class="btn btn-info btn-sm me-1" onclick="showOfficerInfo(<?= $row['Officer_ID'] ?>)">
                    <i class="fa-solid fa-user"></i> Info
                  </button>
                  <form action="approve_request.php" method="POST" class="d-inline">
                    <input type="hidden" name="request_id" value="<?= $row['Request_ID'] ?>">
                    <button class="btn btn-success btn-sm me-1" name="action" value="Approved">
                      <i class="fa-solid fa-check"></i> Approve
                    </button>
                    <button class="btn btn-danger btn-sm" name="action" value="Rejected">
                      <i class="fa-solid fa-xmark"></i> Reject
                    </button>
                  </form>
                </td>
              </tr>
            <?php }} else { ?>
              <tr><td colspan="6" class="text-center text-muted">No pending requests.</td></tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <!-- Approved / Rejected History -->
  <div class="card">
    <div class="card-header bg-secondary text-white">
      <h5 class="mb-0"><i class="fa-solid fa-clock-rotate-left"></i> Request History</h5>
    </div>
    <div class="card-body">
      <div class="table-responsive">
        <table class="table align-middle">
          <thead>
            <tr>
              <th>Officer</th>
              <th>Item</th>
              <th>Qty</th>
              <th>Status</th>
              <th>Date</th>
            </tr>
          </thead>
          <tbody>
            <?php if ($history->num_rows > 0) {
              while ($row = $history->fetch_assoc()) { ?>
              <tr>
                <td><?= htmlspecialchars($row['Officer_Name']) ?></td>
                <td><?= htmlspecialchars($row['Item_Name']) ?></td>
                <td><?= $row['Quantity'] ?></td>
                <td><span class="status <?= $row['Status'] ?>"><?= $row['Status'] ?></span></td>
                <td><?= date('Y-m-d', strtotime($row['Request_Date'])) ?></td>
              </tr>
            <?php }} else { ?>
              <tr><td colspan="5" class="text-center text-muted">No history records.</td></tr>
            <?php } ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

</div>

<!-- Officer Info Modal -->
<div class="modal fade" id="infoModal" tabindex="-1" aria-hidden="true">
  <div class="modal-dialog modal-dialog-centered">
    <div class="modal-content">
      <div class="modal-header bg-primary text-white">
        <h5 class="modal-title"><i class="fa-solid fa-user"></i> Officer Information</h5>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
      </div>
      <div class="modal-body" id="officerDetails">
        <div class="text-center text-muted py-3">Loading...</div>
      </div>
    </div>
  </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
<script>
function showOfficerInfo(id) {
  fetch('officer_info.php?id=' + id)
    .then(res => res.text())
    .then(data => {
      document.getElementById('officerDetails').innerHTML = data;
      new bootstrap.Modal(document.getElementById('infoModal')).show();
    });
}
</script>

</body>
</html>