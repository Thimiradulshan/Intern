<?php
session_start();
include('../db.php');

// ✅ Check session (only DS Officer allowed)
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'DS_Officer') {
    header("Location: ../login.php");
    exit();
}

// ✅ Handle Approve / Reject request
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $request_id = intval($_POST['request_id']);
    $action     = $_POST['action']; // "Approved" or "Rejected"
    $ds_id      = $_SESSION['user_id'];

    // ✅ Step 1: Get officer and total cost
    $sql = "
        SELECT ir.Officer_ID, i.Unit_Price, ir.Quantity
        FROM item_requests ir
        JOIN items i ON ir.Item_ID = i.Item_ID
        WHERE ir.Request_ID = ?
    ";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $request_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows === 0) {
        header("Location: dashboard.php?msg=Invalid request");
        exit();
    }

    $row = $result->fetch_assoc();
    $officer_id = $row['Officer_ID'];
    $total_cost = $row['Unit_Price'] * $row['Quantity'];

    // ✅ Step 2: Update item_requests table
    $update_sql = "
        UPDATE item_requests 
        SET Status = ?, Approved_Date = NOW()
        WHERE Request_ID = ?
    ";
    $stmt2 = $conn->prepare($update_sql);
    $stmt2->bind_param("si", $action, $request_id);
    $stmt2->execute();

    // ✅ Step 3: Insert record into approvals table
    $insert_sql = "
        INSERT INTO approvals (Request_ID, DS_Officer_ID, Approval_Status, Approval_Date)
        VALUES (?, ?, ?, NOW())
    ";
    $stmt3 = $conn->prepare($insert_sql);
    $stmt3->bind_param("iis", $request_id, $ds_id, $action);
    $stmt3->execute();

    // ✅ Step 4: If Approved → Update officer_limit table
    if ($action === 'Approved') {

        $year = date("Y");
        $month = date("n");
        $period = ($month <= 6) ? 'First_Half' : 'Second_Half';

        // 🔍 Check if officer_limit record exists
        $check_exist = $conn->prepare("
            SELECT * FROM officer_limit 
            WHERE Officer_ID = ? AND Year = ? AND Period = ?
        ");
        $check_exist->bind_param("iis", $officer_id, $year, $period);
        $check_exist->execute();
        $res = $check_exist->get_result();

        if ($res->num_rows > 0) {
            // ✅ Update existing record
            $update_limit = $conn->prepare("
                UPDATE officer_limit
                SET 
                    Used_Amount = Used_Amount + ?,
                    Remaining_Amount = Annual_Limit - (Used_Amount + ?)
                WHERE Officer_ID = ? AND Year = ? AND Period = ?
            ");
            $update_limit->bind_param("diiis", $total_cost, $total_cost, $officer_id, $year, $period);
            $update_limit->execute();
        } else {
            // 🆕 Create new record if not exists
            $annual_limit = 2500.00; // default limit
            $used = $total_cost;
            $remaining = $annual_limit - $used;

            $insert_limit = $conn->prepare("
                INSERT INTO officer_limit 
                    (Officer_ID, Year, Period, Annual_Limit, Used_Amount, Remaining_Amount)
                VALUES (?, ?, ?, ?, ?, ?)
            ");
            $insert_limit->bind_param("iissdd", $officer_id, $year, $period, $annual_limit, $used, $remaining);
            $insert_limit->execute();
        }
    }

    // ✅ Step 5: Redirect with message
    header("Location: dashboard.php?msg=Request $action successfully");
    exit();
}
?>

<!-- Optional Alert -->
<?php if (isset($_GET['msg'])) { ?>
<script>
    alert("<?= htmlspecialchars($_GET['msg']) ?>");
</script>
<?php } ?>