<?php
include('../db.php');

if (!isset($_GET['id'])) {
    echo "<div class='alert alert-danger'>Invalid officer ID.</div>";
    exit();
}

$officer_id = intval($_GET['id']);

// Optional filters (year + period)
$year   = date('Y');
$period = (date('n') <= 6) ? 'First_Half' : 'Second_Half';

// Officer info + section + limit + usage
$sql = "
SELECT 
    u.Name, 
    s.section_name, 
    ol.Annual_Limit, 
    COALESCE(SUM(i.Unit_Price * ir.Quantity), 0) AS Used_Amount
FROM users u
LEFT JOIN sections s ON u.section_id = s.section_id
LEFT JOIN officer_limit ol 
       ON ol.Officer_ID = u.ID 
      AND ol.Year = ? 
      AND ol.Period = ?
LEFT JOIN item_requests ir 
       ON ir.Officer_ID = u.ID 
      AND ir.Status = 'Approved'
LEFT JOIN items i ON ir.Item_ID = i.Item_ID
WHERE u.ID = ?
GROUP BY u.ID, ol.Annual_Limit, s.section_name
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("ssi", $year, $period, $officer_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows == 0) {
    echo "<div class='alert alert-warning'>No officer found.</div>";
    exit();
}

$data = $result->fetch_assoc();

$name         = htmlspecialchars($data['Name']);
$section      = htmlspecialchars($data['section_name'] ?? 'N/A');
$annual_limit = $data['Annual_Limit'] ?? 0;
$used_amount  = $data['Used_Amount'] ?? 0;
$remaining    = $annual_limit - $used_amount;
if ($remaining < 0) $remaining = 0;
?>

<style>
.info-card {
    background: #f8faff;
    padding: 15px;
    border-radius: 10px;
    box-shadow: 0 2px 8px rgba(0,0,0,0.08);
    max-width: 600px;
    margin: 0 auto;
}
.info-row {
    display: flex;
    justify-content: space-between;
    padding: 8px 0;
    border-bottom: 1px solid #eee;
}
.info-row:last-child { border-bottom: none; }
.info-title {
    font-weight: 600;
    color: #333;
}
.amount-box {
    display: flex;
    justify-content: space-around;
    margin-top: 15px;
}
.amount-box div {
    text-align: center;
    padding: 10px;
    border-radius: 10px;
    width: 30%;
}
.limit { background: #d4edda; color: #155724; }
.used { background: #fff3cd; color: #856404; }
.balance { background: #cce5ff; color: #004085; }
</style>

<div class="info-card">
  <div class="info-row">
    <div class="info-title">👤 Officer Name:</div>
    <div><?= $name ?></div>
  </div>
  <div class="info-row">
    <div class="info-title">🏢 Section:</div>
    <div><?= $section ?></div>
  </div>
  <div class="info-row">
    <div class="info-title">📅 Period:</div>
    <div><?= $year ?> - <?= $period ?></div>
  </div>

  <div class="amount-box">
    <div class="limit">
      <strong>Annual Limit</strong><br>
      Rs. <?= number_format($annual_limit, 2) ?>
    </div>
    <div class="used">
      <strong>Used Amount</strong><br>
      Rs. <?= number_format($used_amount, 2) ?>
    </div>
    <div class="balance">
      <strong>Remaining</strong><br>
      Rs. <?= number_format($remaining, 2) ?>
    </div>
  </div>
</div>