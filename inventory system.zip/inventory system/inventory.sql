-- ======================================================
-- DATABASE: divisional_secretariat_inventory
-- ======================================================

CREATE DATABASE IF NOT EXISTS divisional_secretariat_inventory;
USE divisional_secretariat_inventory;

-- ======================================================
-- 1️⃣ PROVINCES TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS provinces (
  province_id INT AUTO_INCREMENT PRIMARY KEY,
  province_name VARCHAR(50) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO provinces (province_name) VALUES
('Western Province'),
('Central Province'),
('Southern Province'),
('Northern Province'),
('Eastern Province'),
('North Western Province'),
('North Central Province'),
('Uva Province'),
('Sabaragamuwa Province');

-- ======================================================
-- 2️⃣ DISTRICTS TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS districts (
  district_id INT AUTO_INCREMENT PRIMARY KEY,
  district_name VARCHAR(255) COLLATE utf8mb4_bin NOT NULL,
  province_id INT,
  CONSTRAINT fk_districts_province FOREIGN KEY (province_id) REFERENCES provinces(province_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO districts (district_name, province_id) VALUES
('Ampara', 5),
('Anuradhapura', 7),
('Badulla', 8),
('Batticaloa', 5),
('Colombo', 1),
('Galle', 3),
('Gampaha', 1),
('Hambantota', 3),
('Jaffna', 4),
('Kalutara', 1),
('Kandy', 2),
('Kegalle', 9),
('Kilinochchi', 4),
('Kurunegala', 6),
('Mannar', 4),
('Matale', 2),
('Matara', 3),
('Monaragala', 8),
('Mullaitivu', 4),
('Nuwara Eliya', 2),
('Polonnaruwa', 7),
('Puttalam', 6),
('Ratnapura', 9),
('Trincomalee', 5),
('Vavuniya', 4);

-- ======================================================
-- 3️⃣ DS DIVISIONS TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS ds_divisions (
  dsid INT AUTO_INCREMENT PRIMARY KEY,
  dsname VARCHAR(255) COLLATE utf8mb4_bin NOT NULL,
  district_id INT,
  email VARCHAR(255) COLLATE utf8mb4_bin DEFAULT NULL,
  CONSTRAINT fk_ds_division_district FOREIGN KEY (district_id) REFERENCES districts(district_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

-- ======================================================
-- 4️⃣ SECTIONS TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS sections (
  section_id INT AUTO_INCREMENT PRIMARY KEY,
  section_name VARCHAR(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO sections (section_name) VALUES
('සංවර්ධන අංශය'),
('සමෘධි අංශය'),
('ග්‍රාම නිලධාරී'),
('ක්ෂේත්‍ර නිලධාරීන් (අමාත්‍යංශගත)'),
('පරිපාලන (DS, ADS, AO)'),
('ගිණුම් අංශය'),
('විදේශ රැකියා ප්‍රවර්ධන අංශය'),
('කුඩා ව්‍යාපාර සංවර්ධන අංශය'),
('රෙජිස්ට්‍රාර් අංශය'),
('ආපදා සහන අංශය'),
('බෞද්ධ කටයුතු අංශය'),
('විදාතා සම්පත් මධ්‍යස්ථානය'),
('ඉඩම් අංශය'),
('හැඳුනුම්පත් අංශය'),
('සමාජ සේවා අංශය'),
('ආයතන අංශය');

-- ======================================================
-- 5️⃣ MINISTRIES TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS ministries (
  ministry_id INT AUTO_INCREMENT PRIMARY KEY,
  ministry_name VARCHAR(255) COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

INSERT INTO ministries (ministry_name) VALUES
('Ministry of Defence'),
('Ministry of Finance, Planning and Economic Development'),
('Ministry of Energy'),
('Ministry of Agriculture, Livestock, Land, and Irrigation'),
('Ministry of Justice and National Integration'),
('Ministry of Education, Higher Education and Vocational Education'),
('Ministry of Women and Child Affairs'),
('Ministry of Trade, Commerce, Food Security and Co-operative Development'),
('Ministry of Health and Mass Media'),
('Ministry of Buddhasasana, Religious and Cultural Affairs'),
('Ministry of Transport, Highways, Ports and Civil Aviation'),
('Ministry of Public Security and Parliamentary Affairs'),
('Ministry of Foreign Affairs, Foreign Employment and Tourism'),
('Ministry of Environment'),
('Ministry of Urban Development, Construction and Housing'),
('Ministry of Industry and Entrepreneurship Development'),
('Ministry of Rural Development, Social Security, and Community Empowerment'),
('Ministry of Science and Technology'),
('Ministry of Labour'),
('Ministry of Plantation and Community Infrastructure'),
('Ministry of Public Administration, Provincial Councils and Local Government'),
('Ministry of Fisheries, Aquatic and Ocean Resources'),
('Ministry of Digital Economy'),
('Ministry of Youth Affairs and Sports'),
('North Central Provincial Council'),
('North Western Provincial Council'),
('Northern Provincial Council'),
('Southern Provincial Council'),
('Central Provincial Council'),
('Western Provincial Council'),
('Uva Provincial Council'),
('Eastern Provincial Council'),
('Sabaragamuwa Provincial Council');

-- ======================================================
-- 6️⃣ USERS TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS users (
  ID INT AUTO_INCREMENT PRIMARY KEY,
  Name VARCHAR(255) NOT NULL,
  NIC VARCHAR(12) NOT NULL,
  Birthdate DATE,
  Gender VARCHAR(10),
  Position VARCHAR(100),
  Contact VARCHAR(15),
  Username VARCHAR(50) NOT NULL UNIQUE,
  Password VARCHAR(255) NOT NULL,
  Role ENUM('Admin','DS_Officer','Accountant','Officer') NOT NULL,
  Email VARCHAR(255),
  Limit_ID INT DEFAULT NULL,
  Created_At TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  province_id INT DEFAULT NULL,
  district_id INT DEFAULT NULL,
  dsid INT DEFAULT NULL,
  section_id INT DEFAULT NULL,
  CONSTRAINT fk_user_province FOREIGN KEY (province_id) REFERENCES provinces(province_id),
  CONSTRAINT fk_user_district FOREIGN KEY (district_id) REFERENCES districts(district_id),
  CONSTRAINT fk_user_ds FOREIGN KEY (dsid) REFERENCES ds_divisions(dsid),
  CONSTRAINT fk_user_section FOREIGN KEY (section_id) REFERENCES sections(section_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ======================================================
-- 7️⃣ OFFICER LIMIT TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS officer_limit (
  Limit_ID INT AUTO_INCREMENT PRIMARY KEY,
  Officer_ID INT,
  Annual_Limit DECIMAL(10,2) NOT NULL,
  Used_Amount DECIMAL(10,2) DEFAULT 0,
  CONSTRAINT fk_limit_officer FOREIGN KEY (Officer_ID) REFERENCES users(ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ======================================================
-- 8️⃣ ITEMS TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS items (
  Item_ID INT AUTO_INCREMENT PRIMARY KEY,
  Item_Name VARCHAR(255) NOT NULL,
  Unit_Price DECIMAL(10,2) NOT NULL,
  Quantity INT NOT NULL,
  Total_Value DECIMAL(10,2) GENERATED ALWAYS AS (Unit_Price * Quantity) STORED,
  dsid INT NULL,
  Date_Added TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_item_ds FOREIGN KEY (dsid) REFERENCES ds_divisions(dsid)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ======================================================
-- 9️⃣ ITEM REQUESTS TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS item_requests (
  Request_ID INT AUTO_INCREMENT PRIMARY KEY,
  Officer_ID INT NOT NULL,
  Item_ID INT NOT NULL,
  Quantity INT NOT NULL,
  Request_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  Status ENUM('Pending','Approved','Rejected') DEFAULT 'Pending',
  CONSTRAINT fk_request_officer FOREIGN KEY (Officer_ID) REFERENCES users(ID),
  CONSTRAINT fk_request_item FOREIGN KEY (Item_ID) REFERENCES items(Item_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ======================================================
-- 🔟 APPROVALS TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS approvals (
  Approval_ID INT AUTO_INCREMENT PRIMARY KEY,
  Request_ID INT NOT NULL,
  DS_Officer_ID INT NOT NULL,
  Approval_Status ENUM('Approved','Rejected') DEFAULT 'Approved',
  Approval_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_approval_request FOREIGN KEY (Request_ID) REFERENCES item_requests(Request_ID),
  CONSTRAINT fk_approval_ds FOREIGN KEY (DS_Officer_ID) REFERENCES users(ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ======================================================
-- 1️⃣1️⃣ ISSUED ITEMS TABLE
-- ======================================================
CREATE TABLE IF NOT EXISTS issued_items (
  Issue_ID INT AUTO_INCREMENT PRIMARY KEY,
  Request_ID INT NOT NULL,
  Officer_ID INT NOT NULL,
  Item_ID INT NOT NULL,
  Quantity INT NOT NULL,
  Issue_Date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_issue_request FOREIGN KEY (Request_ID) REFERENCES item_requests(Request_ID),
  CONSTRAINT fk_issue_officer FOREIGN KEY (Officer_ID) REFERENCES users(ID),
  CONSTRAINT fk_issue_item FOREIGN KEY (Item_ID) REFERENCES items(Item_ID)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ======================================================
-- 1️⃣2️⃣ VIEWS
-- ======================================================
CREATE OR REPLACE VIEW total_inventory_value AS
SELECT SUM(Unit_Price * Quantity) AS Total_Stock_Value FROM items;

CREATE OR REPLACE VIEW officer_usage_summary AS
SELECT 
  u.ID AS Officer_ID,
  u.Name AS Officer_Name,
  IFNULL(SUM(i.Unit_Price * iss.Quantity), 0) AS Total_Used_Value
FROM users u
LEFT JOIN issued_items iss ON u.ID = iss.Officer_ID
LEFT JOIN items i ON iss.Item_ID = i.Item_ID
GROUP BY u.ID, u.Name;

COMMIT;