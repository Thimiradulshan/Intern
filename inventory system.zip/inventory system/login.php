<?php
include('db.php');
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = trim($_POST["username"]);
    $password = trim($_POST["password"]);

    $sql = "SELECT * FROM users WHERE Username=? AND Password=?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $username, $password);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows == 1) {
        $user = $result->fetch_assoc();
        $_SESSION["user_id"] = $user["ID"];
        $_SESSION["name"] = $user["Name"];
        $_SESSION["role"] = $user["Role"];

        // ✅ Redirect by role
        switch ($user["Role"]) {
            case 'Officer':
                header("Location: officer/dashboard.php");
                break;
            case 'DS_Officer':
                header("Location: ds_officer/dashboard.php");
                break;
            case 'Accountant':
                header("Location: accountant/dashboard.php");
                break;
            case 'Admin':
                header("Location: admin/dashboard.php");
                break;
            default:
                echo "<script>alert('Invalid role assigned!');</script>";
                break;
        }
        exit();
    } else {
        echo "<script>alert('Invalid username or password');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Login | District Secretariat System</title>

<!-- Google Fonts -->
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<!-- FontAwesome -->
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
:root {
    --primary: #007bff;
    --primary-dark: #0056b3;
    --bg: linear-gradient(135deg, #eaf3ff, #f8fbff);
    --card-bg: rgba(255, 255, 255, 0.9);
}

* {
    box-sizing: border-box;
}

body {
    margin: 0;
    padding: 0;
    height: 100vh;
    background: var(--bg);
    display: flex;
    justify-content: center;
    align-items: center;
    font-family: 'Inter', sans-serif;
    color: #222;
}

/* Centered glass card */
.container {
    width: 380px;
    background: var(--card-bg);
    backdrop-filter: blur(20px);
    border-radius: 16px;
    box-shadow: 0 10px 40px rgba(0,0,0,0.08);
    padding: 45px 40px;
    text-align: center;
    animation: fadeIn 0.8s ease;
}

@keyframes fadeIn {
    from {opacity: 0; transform: translateY(20px);}
    to {opacity: 1; transform: translateY(0);}
}

/* Logo */
.logo {
    background: var(--primary);
    color: #fff;
    width: 70px;
    height: 70px;
    border-radius: 50%;
    margin: 0 auto 18px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 30px;
    box-shadow: 0 6px 20px rgba(0,123,255,0.3);
}

/* Title + Subtitle */
.container h2 {
    margin: 0;
    font-weight: 600;
    font-size: 22px;
}

.container p {
    color: #666;
    font-size: 14px;
    margin-bottom: 30px;
}

/* Input groups */
.input-group {
    position: relative;
    margin-bottom: 18px;
    display: flex;
    justify-content: center;
}

.input-group input {
    width: 100%;
    padding: 12px 40px 12px 14px;
    border: 1px solid #ddd;
    border-radius: 10px;
    font-size: 15px;
    transition: all 0.3s ease;
    background-color: #fff;
}

.input-group input:focus {
    border-color: var(--primary);
    box-shadow: 0 0 6px rgba(0,123,255,0.2);
    outline: none;
}

.input-group i {
    position: absolute;
    right: 15px;
    top: 12px;
    color: #999;
    font-size: 17px;
}

/* Button */
button {
    background: var(--primary);
    color: #fff;
    border: none;
    width: 100%;
    padding: 12px;
    border-radius: 10px;
    font-size: 16px;
    cursor: pointer;
    transition: 0.3s ease;
    font-weight: 500;
    margin-top: 5px;
}

button:hover {
    background: var(--primary-dark);
}

/* Error message */
.message {
    color: red;
    margin-top: 15px;
    font-size: 14px;
}

/* Footer */
.footer {
    margin-top: 25px;
    font-size: 13px;
    color: #777;
}

.footer span {
    color: var(--primary);
    font-weight: 500;
}
</style>
</head>
<body>

<div class="container">
    <div class="logo">
        <i class="fa-solid fa-building-columns"></i>
    </div>
    <h2>District Secretariat System</h2>
    <p>Login to manage your inventory access</p>

    <form method="POST" action="">
        <div class="input-group">
            <input type="text" name="username" placeholder="Enter your username" required>
            <i class="fa-solid fa-user"></i>
        </div>
        <div class="input-group">
            <input type="password" name="password" placeholder="Enter your password" required>
            <i class="fa-solid fa-lock"></i>
        </div>
        <button type="submit">Login</button>
    </form>

    <?php if (!empty($message)) echo "<p class='message'>$message</p>"; ?>

    <div class="footer">
        © <?php echo date('Y'); ?> <span>Inventory Management</span> | All Rights Reserved
    </div>
</div>

</body>
</html>