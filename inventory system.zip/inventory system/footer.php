<!-- footer.php -->
<footer style="text-align:center; padding:10px; color:#777;">
    <p>&copy; <?php echo date("Y"); ?> My Inventory System</p>
</footer>