<?php
session_start();
include('../db.php');

// 🧑‍💼 Check if officer logged in
if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'Officer') {
    header("Location: ../login.php");
    exit();
}

$officer_id = $_SESSION['user_id'];

// ✅ Check if any items selected
if (!isset($_POST['item_ids']) || count($_POST['item_ids']) === 0) {
    die("Please select at least one item to request.");
}

// 🧾 Loop through all selected items
foreach ($_POST['item_ids'] as $item_id) {
    
    // quantity field name = qty_<item_id>
    $qty_field = 'qty_' . $item_id;
    
    // check if quantity provided
    if (!isset($_POST[$qty_field]) || $_POST[$qty_field] <= 0) {
        continue; // skip invalid or empty quantity
    }

    $quantity = intval($_POST[$qty_field]);

    // 🟢 Insert request record
    $insert = $conn->prepare("
        INSERT INTO item_requests (Officer_ID, Item_ID, Quantity, Request_Date, Status)
        VALUES (?, ?, ?, NOW(), 'Pending')
    ");
    $insert->bind_param("iii", $officer_id, $item_id, $quantity);
    $insert->execute();
}

header("Location: dashboard.php?msg=Request submitted successfully");
exit();
?>