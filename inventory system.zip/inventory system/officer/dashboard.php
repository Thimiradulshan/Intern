<?php
include('../db.php');
session_start();

if (!isset($_SESSION['user_id'])) {
    header("Location: ../login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$name = $_SESSION['name'];

$year = date("Y");
$month = date("n");
$period = ($month <= 6) ? 'First_Half' : 'Second_Half';

$check_sql = "SELECT * FROM officer_limit WHERE Officer_ID = ? AND Year = ? AND Period = ?";
$check_stmt = $conn->prepare($check_sql);
$check_stmt->bind_param("iss", $user_id, $year, $period);
$check_stmt->execute();
$check_result = $check_stmt->get_result();

if ($check_result->num_rows === 0) {
    $insert_sql = "INSERT INTO officer_limit (Officer_ID, Year, Period, Annual_Limit, Used_Amount)
                   VALUES (?, ?, ?, 0, 0)";
    $insert_stmt = $conn->prepare($insert_sql);
    $insert_stmt->bind_param("iss", $user_id, $year, $period);
    $insert_stmt->execute();
}

$limit_sql = "SELECT Annual_Limit, Used_Amount FROM officer_limit 
              WHERE Officer_ID = ? AND Year = ? AND Period = ?";
$stmt = $conn->prepare($limit_sql);
$stmt->bind_param("iss", $user_id, $year, $period);
$stmt->execute();
$result = $stmt->get_result();
$limit_data = $result->fetch_assoc();

$annual_limit = $limit_data['Annual_Limit'] ?? 0;
$used_amount = $limit_data['Used_Amount'] ?? 0;
$remaining = $annual_limit - $used_amount;

$req_sql = "SELECT ir.Request_ID, i.Item_Name, ir.Quantity, ir.Status, ir.Request_Date
            FROM item_requests ir
            JOIN items i ON ir.Item_ID = i.Item_ID
            WHERE ir.Officer_ID = ?
            ORDER BY ir.Request_Date DESC";
$stmt2 = $conn->prepare($req_sql);
$stmt2->bind_param("i", $user_id);
$stmt2->execute();
$requests = $stmt2->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Officer Dashboard | Inventory System</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">

<style>
:root {
    --primary: #004085;
    --secondary: #17A2B8;
    --accent: #FFC107;
    --bg: #F8F9FA;
    --text: #212529;
}
body {
    margin: 0;
    font-family: 'Inter', sans-serif;
    background: var(--bg);
    color: var(--text);
}
header {
    background: linear-gradient(90deg, var(--primary), var(--secondary));
    color: white;
    padding: 20px 40px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
}
header h2 {
    margin: 0;
    font-weight: 600;
    font-size: 1.4rem;
}
.logout-btn {
    background: var(--accent);
    color: #000;
    border: none;
    padding: 8px 16px;
    border-radius: 6px;
    font-weight: 600;
    cursor: pointer;
    transition: 0.3s;
}
.logout-btn:hover {
    background: #e0a800;
}
.dashboard {
    display: flex;
    flex-wrap: wrap;
    gap: 15px;
    justify-content: center;
    padding: 25px 10px;
}

/* Each card box */
.card {
    background: white;
    border-radius: 12px;
    box-shadow: 0 3px 6px rgba(0,0,0,0.1);
    width: 180px;
    text-align: center;
    padding: 18px 12px;
    transition: all 0.3s ease;
    position: relative;
    overflow: hidden;
}

/* Hover effect - subtle pop */
.card:hover {
    transform: translateY(-6px);
    box-shadow: 0 6px 12px rgba(0,0,0,0.15);
}

/* Accent line on top of each card */
.card::before {
    content: "";
    position: absolute;
    top: 0; left: 0;
    width: 100%; height: 5px;
    border-top-left-radius: 14px;
    border-top-right-radius: 14px;
}

/* Custom colors for each box */
.card:nth-child(1)::before { background: #17A2B8; } /* Year */
.card:nth-child(2)::before { background: #20C997; } /* Period */
.card:nth-child(3)::before { background: #004085; } /* Limit */
.card:nth-child(4)::before { background: #FFC107; } /* Used */
.card:nth-child(5)::before { background: #28A745; } /* Remaining */

.card h3 {
    margin: 6px 0px;
    font-size: 0.95rem;
    color: #004085;
    font-weight: 600;
}

.card p {
    font-size: 1.2rem;
    font-weight: 700;
    color: #212529;
}
.table-container {
    width: 85%; /* 👈 narrow width (was 90%) */
    margin: 20px auto;
    background: white;
    border-radius: 12px;
    box-shadow: 0 3px 8px rgba(0,0,0,0.05);
    padding: 15px;
}

.table-container h3 {
    margin-bottom: 12px;
    color: var(--primary);
    font-weight: 600;
    font-size: 1.1rem;
    text-align: center;
}

table {
    width: 100%;
    border-collapse: collapse;
    font-size: 0.9rem; /* 👈 smaller text */
}
th, td {
    padding: 8px 10px; /* 👈 tighter spacing */
    text-align: center;
    border-bottom: 1px solid #eee;
}
th {
    background: var(--primary);
    color: white;
    font-weight: 600;
    text-transform: uppercase;
}
}
.status {
    padding: 6px 12px;
    border-radius: 8px;
    font-size: 13px;
    font-weight: 600;
}
.Pending {
    background: #fff3cd;
    color: #856404;
}
.Approved {
    background: #d4edda;
    color: #155724;
}
.Rejected {
    background: #f8d7da;
    color: #721c24;
}

.request-btn {
    background: #004085;
    color: white;
    border: none;
    padding: 8px 16px;           /* smaller size */
    border-radius: 6px;
    font-size: 14px;             /* slightly smaller text */
    margin: 15px auto 25px;      /* perfectly centered */
    display: block;
    width: fit-content;          /* keeps button width tight to text */
    cursor: pointer;
    font-weight: 500;
    transition: all 0.3s ease;
    text-align: center;
}

.request-btn:hover {
    background: #002f6c;
    transform: scale(1.03);
}
</style>
</head>
<body>

<header>
    <h2>Welcome, <?php echo htmlspecialchars($name); ?> 👋</h2>
    <form action="../logout.php" method="POST">
        <button class="logout-btn">Logout</button>
    </form>
</header>

<div class="dashboard">
    <div class="card">
        <h3>Year</h3>
        <p><?php echo $year; ?></p>
    </div>
    <div class="card">
        <h3>Period</h3>
        <p><?php echo ($period == 'First_Half') ? 'First Half (Jan–Jun)' : 'Second Half (Jul–Dec)'; ?></p>
    </div>
    <div class="card">
        <h3>Limit</h3>
        <p>Rs. <?php echo number_format($annual_limit,2); ?></p>
    </div>
    <div class="card">
        <h3>Used</h3>
        <p>Rs. <?php echo number_format($used_amount,2); ?></p>
    </div>
    <div class="card">
        <h3>Remaining</h3>
        <p>Rs. <?php echo number_format($remaining,2); ?></p>
    </div>
</div>

<div class="table-container">
    <h3>🧾 Your Requested Items</h3>
    <table>
        <tr>
            <th>Item</th>
            <th>Quantity</th>
            <th>Status</th>
            <th>Date</th>
        </tr>
        <?php while ($row = $requests->fetch_assoc()) { ?>
        <tr>
            <td><?php echo htmlspecialchars($row['Item_Name']); ?></td>
            <td><?php echo $row['Quantity']; ?></td>
            <td><span class="status <?php echo $row['Status']; ?>"><?php echo $row['Status']; ?></span></td>
            <td><?php echo date('Y-m-d', strtotime($row['Request_Date'])); ?></td>
        </tr>
        <?php } ?>
    </table>
</div>

<a href="request_item.php" class="request-btn">
    <i class="fas fa-box-open"></i> Request New Item
</a>

</body>
</html>