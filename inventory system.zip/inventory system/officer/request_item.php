<?php
include('../db.php');
session_start();

// Officer Dashboard link එක සඳහා
$dashboard_link = "dashboard.php";

$result = $conn->query("SELECT * FROM items");
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Select Item to Request</title>
<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<style>
body {
    margin: 0;
    font-family: 'Inter', sans-serif;
    background: #f5f8ff;
    color: #333;
}

/* 🔹 Title bar */
h3.fw-bold {
    color: #0056b3;
    font-weight: 600;
}

/* 🔹 Dashboard Button */
.btn-outline-secondary {
    color: white;
    background: linear-gradient(90deg, #007bff, #0056b3);
    border: none;
    transition: 0.3s;
}
.btn-outline-secondary:hover {
    background: #004a99;
    color: #fff;
}

/* 🔹 Cards */
.card {
    background: white;
    border-radius: 14px;
    box-shadow: 0 4px 12px rgba(0,0,0,0.08);
    border: none;
    transition: 0.3s ease;
}
.card:hover {
    transform: translateY(-6px);
    box-shadow: 0 6px 18px rgba(0,0,0,0.1);
}
.card img {
    height: 160px;
    object-fit: contain;
    background: #eef4ff;
    border-top-left-radius: 14px;
    border-top-right-radius: 14px;
}
.card-body {
    background: #ffffff;
    padding: 15px 10px;
}
.card-title {
    font-weight: 600;
    color: #0056b3;
}
.price {
    color: #007bff;
    font-weight: 600;
}

/* 🔹 Quantity input + checkbox */
.form-control {
    border-radius: 8px;
    border: 1px solid #ccd8ff;
}
.form-check-input:checked {
    background-color: #007bff;
    border-color: #007bff;
}

/* 🔹 Submit Button */
.btn-primary {
    background: linear-gradient(90deg, #007bff, #0056b3);
    border: none;
    border-radius: 10px;
    font-weight: 500;
    font-size: 16px;
    transition: 0.3s;
}
.btn-primary:hover {
    background: #004a99;
    transform: translateY(-2px);
}
</style>
</head>
<body class="bg-light">

<div class="container py-4">
    <!-- 🔹 Top Section with Title and Dashboard Button -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold mb-0">🛒 Select Items to Request</h3>
        <a href="<?php echo $dashboard_link; ?>" class="btn btn-outline-secondary">
            ← Back to Dashboard
        </a>
    </div>

    <form action="submit_request.php" method="POST">
        <div class="row g-4">
            <?php while($row = $result->fetch_assoc()): ?>
                <div class="col-md-3">
                    <div class="card h-100">
                        <img src="../uploads/<?php echo htmlspecialchars($row['Image']); ?>" 
                             class="card-img-top" alt="<?php echo htmlspecialchars($row['Item_Name']); ?>">
                        <div class="card-body text-center">
                            <h6 class="card-title"><?php echo htmlspecialchars($row['Item_Name']); ?></h6>
                            <p class="price">Rs. <?php echo number_format($row['Unit_Price'], 2); ?></p>
                            <div class="form-check d-flex justify-content-center">
                                <input class="form-check-input me-2" type="checkbox" name="item_ids[]" value="<?php echo $row['Item_ID']; ?>">
                                <label class="form-check-label">Select</label>
                            </div>
                            <input type="number" class="form-control mt-2" name="qty_<?php echo $row['Item_ID']; ?>" placeholder="Enter Quantity" min="1">
                        </div>
                    </div>
                </div>
            <?php endwhile; ?>
        </div>

        <div class="text-center mt-4">
            <button type="submit" class="btn btn-primary px-5 py-2">Submit Request</button>
        </div>
    </form>
</div>

</body>
</html>